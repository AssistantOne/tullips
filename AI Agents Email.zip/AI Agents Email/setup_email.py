#!/usr/bin/env python3
"""
Email Configuration Setup Script
This script helps you set up email credentials for the contract sending feature.
"""

import os
import getpass
import secrets

def create_env_file():
    """Create a .env file with email configuration"""
    
    print("=== Email Configuration Setup ===")
    print("This will help you set up Gmail credentials for sending contracts.")
    print()
    
    # Check if .env file already exists
    if os.path.exists('.env'):
        print("⚠️  .env file already exists!")
        overwrite = input("Do you want to overwrite it? (y/N): ").lower().strip()
        if overwrite != 'y':
            print("Setup cancelled.")
            return
    
    # Get email credentials
    print("Enter your Gmail credentials:")
    email = input("Gmail address: ").strip()
    
    if not email or '@gmail.com' not in email:
        print("❌ Please enter a valid Gmail address.")
        return
    
    print("\n⚠️  IMPORTANT: You need to use a Gmail App Password, not your regular password!")
    print("To create an App Password:")
    print("1. Go to your Google Account settings")
    print("2. Enable 2-Step Verification if not already enabled")
    print("3. Go to Security > App passwords")
    print("4. Generate a new app password for 'Mail'")
    print("5. Use that password below")
    print()
    
    password = getpass.getpass("Gmail App Password: ").strip()
    
    if not password:
        print("❌ Password cannot be empty.")
        return
    
    # Generate a secret key
    secret_key = secrets.token_hex(32)
    
    # Create .env content
    env_content = f"""# Email Configuration for Contract Sending
EMAIL_USER={email}
EMAIL_PASSWORD={password}

# Application Configuration
SECRET_KEY={secret_key}
SQLALCHEMY_TRACK_MODIFICATIONS=False

# Mail Server Configuration (Gmail)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME={email}
MAIL_PASSWORD={password}
MAIL_DEFAULT_SENDER={email}
"""
    
    # Write to .env file
    try:
        with open('.env', 'w') as f:
            f.write(env_content)
        
        print("\n✅ .env file created successfully!")
        print(f"📧 Email: {email}")
        print("🔐 Password: [hidden]")
        print("\n🚀 You can now restart your application and try sending contracts.")
        
    except Exception as e:
        print(f"❌ Error creating .env file: {e}")

def test_email_config():
    """Test the email configuration"""
    print("\n=== Testing Email Configuration ===")
    
    if not os.path.exists('.env'):
        print("❌ .env file not found. Please run setup first.")
        return
    
    # Load environment variables
    from dotenv import load_dotenv
    load_dotenv()
    
    email = os.getenv('EMAIL_USER')
    password = os.getenv('EMAIL_PASSWORD')
    
    if not email or not password:
        print("❌ Email credentials not found in .env file.")
        return
    
    print(f"📧 Testing with email: {email}")
    
    # Test SMTP connection
    try:
        import smtplib
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(email, password)
        server.quit()
        print("✅ Email configuration test successful!")
        print("You can now send contracts from the admin dashboard.")
    except Exception as e:
        print(f"❌ Email configuration test failed: {e}")
        print("Please check your Gmail App Password and try again.")

if __name__ == "__main__":
    print("Choose an option:")
    print("1. Create/Update .env file")
    print("2. Test email configuration")
    print("3. Both")
    
    choice = input("Enter your choice (1-3): ").strip()
    
    if choice == "1":
        create_env_file()
    elif choice == "2":
        test_email_config()
    elif choice == "3":
        create_env_file()
        test_email_config()
    else:
        print("Invalid choice.") 