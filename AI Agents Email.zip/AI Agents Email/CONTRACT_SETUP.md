# Contract Sending Setup Guide

## Problem
When you try to send a contract from the Contract Center, it fails with an error message.

## Root Cause
The application is missing email credentials configuration. The contract sending feature requires Gmail credentials to send emails with PDF attachments.

## Solution

### Option 1: Use the Setup Script (Recommended)

1. **Run the setup script:**
   ```bash
   python setup_email.py
   ```

2. **Choose option 1** to create/update the .env file

3. **Enter your Gmail credentials:**
   - Gmail address: your-email@gmail.com
   - Gmail App Password: (see instructions below)

4. **Restart your application**

### Option 2: Manual Setup

1. **Create a .env file** in the root directory with the following content:
   ```
   EMAIL_USER=your-email@gmail.com
   EMAIL_PASSWORD=your-app-password
   SECRET_KEY=your-secret-key-here
   SQLALCHEMY_TRACK_MODIFICATIONS=False
   MAIL_SERVER=smtp.gmail.com
   MAIL_PORT=587
   MAIL_USE_TLS=True
   MAIL_USERNAME=your-email@gmail.com
   MAIL_PASSWORD=your-app-password
   MAIL_DEFAULT_SENDER=your-email@gmail.com
   ```

2. **Replace the placeholders** with your actual values

3. **Restart your application**

## Gmail App Password Setup

**IMPORTANT:** You must use a Gmail App Password, not your regular Gmail password.

### Steps to create a Gmail App Password:

1. **Go to your Google Account settings:**
   - Visit https://myaccount.google.com/
   - Sign in with your Gmail account

2. **Enable 2-Step Verification** (if not already enabled):
   - Go to Security > 2-Step Verification
   - Follow the setup process

3. **Create an App Password:**
   - Go to Security > App passwords
   - Select "Mail" as the app
   - Select "Other" as the device
   - Click "Generate"
   - Copy the 16-character password

4. **Use the App Password** in your .env file instead of your regular Gmail password

## Testing the Configuration

After setting up the credentials, you can test them:

```bash
python setup_email.py
```

Choose option 2 to test the email configuration.

## Troubleshooting

### Common Issues:

1. **"Email credentials not configured"**
   - Make sure you have a .env file in the root directory
   - Check that EMAIL_USER and EMAIL_PASSWORD are set correctly

2. **"Email authentication failed"**
   - Ensure you're using a Gmail App Password, not your regular password
   - Verify that 2-Step Verification is enabled on your Google Account
   - Check that the App Password was generated for "Mail"

3. **"SMTP error occurred"**
   - Check your internet connection
   - Verify that your Gmail account allows "less secure app access" or use App Passwords
   - Ensure the email address is correct

### Error Messages:

The application now shows specific error messages to help you troubleshoot:

- **"Email credentials not configured"** → Set up your .env file
- **"Email authentication failed"** → Check your Gmail App Password
- **"SMTP error occurred"** → Check your internet connection and Gmail settings

## Security Notes

- Never commit your .env file to version control
- Keep your App Password secure
- The .env file is already in .gitignore to prevent accidental commits
- App Passwords are more secure than regular passwords for this use case

## Support

If you continue to have issues after following this guide, check:

1. Your Gmail account settings
2. The application logs for detailed error messages
3. Your firewall/antivirus settings that might block SMTP connections 