import os
from flask import Flask, jsonify, send_from_directory, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask import request
from flask_mail import Mail, Message
from dotenv import load_dotenv
from datetime import datetime, timedelta
import secrets
from werkzeug.utils import secure_filename
import threading
import time
import imaplib
import email as pyemail
from email.header import decode_header
import smtplib
from email.mime.text import MIMEText
import openai
import re
from EnhancedBrandBot import EnhancedBrandBot
import json
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

# Load environment variables from .env
load_dotenv()

# Debug: Check if environment variables are loaded
print(f"DEBUG: EMAIL_USER from env: {os.environ.get('EMAIL_USER', 'NOT_SET')}")
print(f"DEBUG: EMAIL_PASSWORD from env: {'SET' if os.environ.get('EMAIL_PASSWORD') else 'NOT_SET'}")

app = Flask(__name__, static_folder='static', static_url_path='/static', template_folder='templates')
CORS(app)

# --- File Upload Config ---
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Print the database URI for debugging
print("DB URI:", os.getenv('SQLALCHEMY_DATABASE_URI'))
# Print the absolute path to the database file for debugging
print("DB absolute path:", os.path.abspath("instance/users.db"))

# Config from environment variables
# DEBUG: Use project root for database to avoid instance directory issues
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = os.getenv('SQLALCHEMY_TRACK_MODIFICATIONS', 'False') == 'True'
app.secret_key = os.getenv('SECRET_KEY', 'supersecretkey')

# Mail config
app.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER', 'smtp.example.com')
app.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT', 587))
app.config['MAIL_USE_TLS'] = os.getenv('MAIL_USE_TLS', 'True') == 'True'
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME', '')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD', '')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_DEFAULT_SENDER', 'noreply@retrograde.com')

mail = Mail(app)

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    instagram = db.Column(db.String(64))
    tiktok = db.Column(db.String(64))
    youtube = db.Column(db.String(64))
    # --- New Profile Fields ---
    name = db.Column(db.String(100))
    address = db.Column(db.String(200))
    pfp = db.Column(db.String(200)) # URL or path to profile picture
    gender = db.Column(db.String(20)) # Male, Female, Other
    dob = db.Column(db.Date) # Date of Birth
    phone = db.Column(db.String(20))
    bio = db.Column(db.String(500))
    # --- Gmail Integration ---
    gmail = db.Column(db.String(120))
    gmail_app_password = db.Column(db.String(32))
    # --- PDF Attachment for Email Processing ---
    pdf_attachment = db.Column(db.String(500)) # Path to PDF file for this user
    pdf_content = db.Column(db.Text) # Extracted text content from PDF
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def get_id(self):
        return str(self.id)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def serve_index():
    return render_template('index.html')

@app.route('/<path:filename>')
def serve_static_or_template(filename):
    # Serve static files
    static_path = os.path.join(app.static_folder, filename)
    if os.path.exists(static_path):
        return send_from_directory(app.static_folder, filename)
    # Serve HTML templates
    if filename.endswith('.html'):
        try:
            return render_template(filename)
        except Exception:
            return jsonify({'error': 'File not found'}), 404
    return jsonify({'error': 'File not found'}), 404

@app.route('/api/hello')
def hello():
    return jsonify({"message": "Hello from Flask backend!"})

@app.route('/api/signup', methods=['POST'])
def signup():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    instagram = data.get('instagram')
    tiktok = data.get('tiktok')
    youtube = data.get('youtube')
    if not email or not password or not instagram:
        return jsonify({'error': 'Missing required fields'}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 409
    hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')
    user = User(email=email, password=hashed_pw, instagram=instagram, tiktok=tiktok, youtube=youtube)
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully'})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    user = User.query.filter_by(email=email).first()
    if not user or not bcrypt.check_password_hash(user.password, password):
        return jsonify({'error': 'Invalid credentials'}), 401
    login_user(user)
    return jsonify({'message': 'Login successful', 'is_admin': user.is_admin})

@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    user = User.query.filter_by(email=email, is_admin=True).first()
    if not user or not bcrypt.check_password_hash(user.password, password):
        return jsonify({'error': 'Invalid admin credentials'}), 401
    login_user(user)
    return jsonify({'message': 'Admin login successful'})

@app.route('/api/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return jsonify({'message': 'Logged out'})

# --- Profile API Endpoints ---
@app.route('/api/profile', methods=['GET'])
@login_required
def get_profile():
    return jsonify({
        'username': current_user.email.split('@')[0],
        'email': current_user.email,
        'name': current_user.name,
        'address': current_user.address,
        'pfp': current_user.pfp,
        'gender': current_user.gender,
        'dob': current_user.dob.isoformat() if current_user.dob else None,
        'phone': current_user.phone,
        'bio': current_user.bio,
        'is_admin': current_user.is_admin
    })

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def allowed_pdf_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() == 'pdf'

@app.route('/api/profile', methods=['POST'])
@login_required
def update_profile():
    # Update text fields
    current_user.name = request.form.get('name')
    current_user.address = request.form.get('address')
    current_user.gender = request.form.get('gender')
    dob_str = request.form.get('dob')
    if dob_str:
        try:
            current_user.dob = datetime.strptime(dob_str, '%Y-%m-%d').date()
        except Exception:
            pass
    current_user.phone = request.form.get('phone')
    current_user.bio = request.form.get('bio')
    
    # Handle file upload
    if 'pfp' in request.files:
        file = request.files['pfp']
        if file and file.filename != '' and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            # To avoid filename collisions, prepend user ID
            unique_filename = f"{current_user.id}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(file_path)
            current_user.pfp = f"/uploads/{unique_filename}"

    db.session.commit()
    return jsonify({'message': 'Profile updated successfully'})

@app.route('/api/gmail-settings', methods=['GET'])
@login_required
def get_gmail_settings():
    return jsonify({
        'gmail': current_user.gmail or ''
    })

@app.route('/api/gmail-settings', methods=['POST'])
@login_required
def update_gmail_settings():
    gmail = request.form.get('gmail')
    app_password = request.form.get('appPassword')
    if gmail:
        current_user.gmail = gmail
    if app_password:
        current_user.gmail_app_password = app_password
    db.session.commit()
    return jsonify({'message': 'Gmail settings updated successfully'})

# --- Admin API Endpoints ---
@app.route('/api/admin/users', methods=['GET'])
@login_required
def get_all_users():
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    users = User.query.all()
    users_data = []
    for user in users:
        users_data.append({
            'id': user.id,
            'email': user.email,
            'name': user.name,
            'instagram': user.instagram,
            'tiktok': user.tiktok,
            'youtube': user.youtube,
            'phone': user.phone,
            'bio': user.bio,
            'gmail': user.gmail,
            'pdf_attachment': user.pdf_attachment,
            'has_pdf': bool(user.pdf_attachment),
            'created_at': user.created_at.isoformat() if user.created_at else None,
            'updated_at': user.updated_at.isoformat() if user.updated_at else None
        })
    return jsonify(users_data)

@app.route('/api/admin/users/<int:user_id>', methods=['GET'])
@login_required
def get_user_details(user_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    user = User.query.get_or_404(user_id)
    return jsonify({
        'id': user.id,
        'email': user.email,
        'name': user.name,
        'instagram': user.instagram,
        'tiktok': user.tiktok,
        'youtube': user.youtube,
        'phone': user.phone,
        'bio': user.bio,
        'gmail': user.gmail,
        'pdf_attachment': user.pdf_attachment,
        'pdf_content': user.pdf_content,
        'created_at': user.created_at.isoformat() if user.created_at else None,
        'updated_at': user.updated_at.isoformat() if user.updated_at else None
    })

@app.route('/api/admin/users/<int:user_id>', methods=['PUT'])
@login_required
def update_user_profile(user_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    user = User.query.get_or_404(user_id)
    data = request.json
    
    # Update user fields
    if 'name' in data:
        user.name = data['name']
    if 'instagram' in data:
        user.instagram = data['instagram']
    if 'tiktok' in data:
        user.tiktok = data['tiktok']
    if 'youtube' in data:
        user.youtube = data['youtube']
    if 'phone' in data:
        user.phone = data['phone']
    if 'bio' in data:
        user.bio = data['bio']
    if 'gmail' in data:
        user.gmail = data['gmail']
    
    db.session.commit()
    return jsonify({'message': 'User profile updated successfully'})

@app.route('/api/admin/users/<int:user_id>/pdf', methods=['POST'])
@login_required
def upload_user_pdf(user_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    user = User.query.get_or_404(user_id)
    
    if 'pdf_file' not in request.files:
        return jsonify({'error': 'No PDF file provided'}), 400
    
    file = request.files['pdf_file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if file and allowed_pdf_file(file.filename):
        # Create user-specific PDF directory
        user_pdf_dir = os.path.join('pdfs', f'user_{user_id}')
        os.makedirs(user_pdf_dir, exist_ok=True)
        
        # Save the PDF file
        filename = secure_filename(file.filename)
        file_path = os.path.join(user_pdf_dir, filename)
        file.save(file_path)
        
        # Extract text from PDF
        try:
            import PyPDF2
            pdf_text = ""
            with open(file_path, 'rb') as pdf_file:
                pdf_reader = PyPDF2.PdfReader(pdf_file)
                for page in pdf_reader.pages:
                    pdf_text += page.extract_text() + "\n"
            
            # Update user record
            user.pdf_attachment = file_path
            user.pdf_content = pdf_text
            db.session.commit()
            
            return jsonify({
                'message': 'PDF uploaded and processed successfully',
                'file_path': file_path,
                'content_length': len(pdf_text)
            })
        except Exception as e:
            return jsonify({'error': f'Error processing PDF: {str(e)}'}), 500
    
    return jsonify({'error': 'Invalid file type'}), 400

@app.route('/api/admin/users/<int:user_id>/pdf', methods=['DELETE'])
@login_required
def delete_user_pdf(user_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    user = User.query.get_or_404(user_id)
    
    if user.pdf_attachment and os.path.exists(user.pdf_attachment):
        os.remove(user.pdf_attachment)
    
    user.pdf_attachment = None
    user.pdf_content = None
    db.session.commit()
    
    return jsonify({'message': 'PDF removed successfully'})

@app.route('/api/admin/users/<int:user_id>', methods=['DELETE'])
@login_required
def delete_user(user_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    user = User.query.get_or_404(user_id)
    
    # Delete associated PDF file
    if user.pdf_attachment and os.path.exists(user.pdf_attachment):
        os.remove(user.pdf_attachment)
    
    # Delete user
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'message': 'User deleted successfully'})

# Test endpoint removed - system now only works with real emails



@app.route('/api/admin/users/<int:user_id>/conversation-history', methods=['GET'])
@login_required
def get_user_conversation_history_admin(user_id):
    """Get conversation history for a specific user (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        history = brand_bot.get_user_conversation_history(user_id)
        stats = brand_bot.get_user_conversation_stats(user_id)
        return jsonify({
            'success': True,
            'history': history,
            'stats': stats
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/users/<int:user_id>/conversation-history', methods=['DELETE'])
@login_required
def clear_user_conversation_history_admin(user_id):
    """Clear conversation history for a specific user (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        brand_bot.clear_user_conversation_history(user_id)
        return jsonify({'success': True, 'message': 'Conversation history cleared'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/users/interest-analysis', methods=['GET'])
@login_required
def get_all_users_interest_analysis():
    """Get interest analysis for all users (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        users = User.query.all()
        interest_data = []
        
        for user in users:
            interest_analysis = brand_bot.detect_user_interest(user.id)
            user_data = {
                'id': user.id,
                'name': user.name or 'N/A',
                'email': user.email,
                'interest_status': interest_analysis['status'],
                'confidence': interest_analysis['confidence'],
                'reason': interest_analysis['reason'],
                'last_analyzed': interest_analysis['last_analyzed'],
                'indicators': interest_analysis.get('indicators', {})
            }
            interest_data.append(user_data)
        
        return jsonify({
            'success': True,
            'users': interest_data,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/users/<int:user_id>/interest', methods=['GET'])
@login_required
def get_user_interest_analysis(user_id):
    """Get interest analysis for a specific user (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        user = User.query.get_or_404(user_id)
        interest_analysis = brand_bot.detect_user_interest(user.id)
        
        return jsonify({
            'success': True,
            'user': {
                'id': user.id,
                'name': user.name or 'N/A',
                'email': user.email
            },
            'interest_analysis': interest_analysis
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/users/<int:user_id>/interest', methods=['PUT'])
@login_required
def update_user_interest_status(user_id):
    """Manually update user interest status (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        data = request.get_json()
        new_status = data.get('status')  # 'interested', 'not_interested', 'unknown'
        
        if new_status not in ['interested', 'not_interested', 'unknown']:
            return jsonify({'error': 'Invalid status'}), 400
        
        # Store manual override in user's conversation history
        override_message = f"Manual override: Interest status set to '{new_status}' by admin"
        brand_bot.add_to_user_conversation(user_id, "system", override_message, "Interest Override")
        
        return jsonify({
            'success': True,
            'message': f'Interest status updated to {new_status}',
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/users/take-over', methods=['POST'])
@login_required
def take_over_user_interest_analysis():
    """Take over interest analysis for a user by email (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        data = request.get_json()
        email_address = data.get('email')
        
        if not email_address:
            return jsonify({'error': 'Email address is required'}), 400
            
        print(f"Take-over request for email: {email_address}")
        # Get user details by email
        user = User.query.filter_by(email=email_address).first()
        user_id = user.id if user else -1  # Use -1 for external emails
        user_name = user.name if user else email_address
        
        if user:
            print(f"User found: {user.email} (ID: {user.id})")
        else:
            print(f"User not found for email: {email_address} - will store as external email")
        
        # Get the current interest analysis to determine original status
        try:
            if user_id:
                interest_analysis = brand_bot.analyze_interest_by_email(user_id, user.email)
                original_status = interest_analysis.get('status', 'unknown') if interest_analysis else 'unknown'
            else:
                # For external emails, we can't analyze interest without user context
                original_status = 'unknown'
        except Exception as e:
            print(f"Error analyzing interest for user {user_id}: {e}")
            original_status = 'unknown'
        
        # Save to TakeoverEmail database
        print(f"Saving takeover email to database...")
        takeover_email = TakeoverEmail(
            user_id=user_id,
            email_address=email_address,
            user_name=user_name,
            original_status=original_status,
            taken_over_by=current_user.id,
            notes=f"Taken over by admin {current_user.email} at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )
        db.session.add(takeover_email)
        db.session.commit()
        print(f"Takeover email saved successfully with ID: {takeover_email.id}")
        
        # Add take-over message to user's conversation history (only if user exists)
        if user_id > 0:  # Only for actual users, not external emails
            print(f"Adding take-over message to conversation history...")
            take_over_message = f"Admin takeover: Interest analysis taken over by admin at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            brand_bot.add_to_user_conversation(user_id, "system", take_over_message, "Admin Takeover")
            print(f"Take-over message added to conversation history")
        else:
            print(f"External email - skipping conversation history update")
        
        user_identifier = user.id if user else email_address
        print(f"Take-over completed successfully for {user_identifier}")
        return jsonify({
            'success': True,
            'message': 'Successfully took over interest analysis',
            'user_id': user_id,
            'email': email_address,
            'takeover_id': takeover_email.id,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        print(f"Error in take-over route: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/takeover-emails', methods=['GET'])
@login_required
def get_takeover_emails():
    """Get all emails that have been taken over (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        takeover_emails = TakeoverEmail.query.order_by(TakeoverEmail.taken_over_at.desc()).all()
        return jsonify([email.to_dict() for email in takeover_emails])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/send-contract', methods=['POST'])
@login_required
def send_contract():
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    if 'pdf' not in request.files:
        return jsonify({'error': 'No PDF file provided'}), 400
    
    pdf_file = request.files['pdf']
    email_to = request.form.get('email')
    
    if not email_to:
        return jsonify({'error': 'No email address provided'}), 400

    if pdf_file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if pdf_file and pdf_file.filename.endswith('.pdf'):
        filename = secure_filename(pdf_file.filename)
        
        try:
            # Get email credentials from environment variables
            sender_email = os.environ.get('EMAIL_USER')
            sender_password = os.environ.get('EMAIL_PASSWORD')
            
            print(f"DEBUG: sender_email = {sender_email}")
            print(f"DEBUG: sender_password = {'*' * len(sender_password) if sender_password else 'None'}")
            
            if not sender_email or not sender_password:
                return jsonify({'error': 'Email credentials not configured. Please set EMAIL_USER and EMAIL_PASSWORD in your .env file.'}), 500

            print(f"DEBUG: Creating email message...")
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = email_to
            msg['Subject'] = 'Your Contract from Retrograde'
            
            body = 'Please find your contract attached.'
            msg.attach(MIMEText(body, 'plain'))
            
            print(f"DEBUG: Reading PDF file...")
            pdf_content = pdf_file.read()
            print(f"DEBUG: PDF content length: {len(pdf_content)} bytes")
            
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(pdf_content)
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename={filename}')
            msg.attach(part)
            
            print(f"DEBUG: Connecting to SMTP server...")
            server = smtplib.SMTP('smtp.gmail.com', 587)
            print(f"DEBUG: Starting TLS...")
            server.starttls()
            print(f"DEBUG: Logging in...")
            server.login(sender_email, sender_password)
            print(f"DEBUG: Converting message to string...")
            text = msg.as_string()
            print(f"DEBUG: Sending email...")
            server.sendmail(sender_email, email_to, text)
            print(f"DEBUG: Closing connection...")
            server.quit()
            
            print(f"Sending contract {filename} to {email_to}")
            
            return jsonify({'success': True, 'message': 'Contract sent successfully'})
        except smtplib.SMTPAuthenticationError as e:
            return jsonify({'error': 'Email authentication failed. Please check your Gmail credentials and ensure you are using an App Password.'}), 500
        except smtplib.SMTPException as e:
            return jsonify({'error': f'SMTP error occurred: {str(e)}'}), 500
        except Exception as e:
            return jsonify({'error': f'Failed to send email: {str(e)}'}), 500
            
    return jsonify({'error': 'Invalid file type, only PDF is allowed'}), 400


@app.route('/api/admin/takeover-emails/<int:email_id>', methods=['DELETE'])
@login_required
def remove_takeover_email(email_id):
    """Remove an email from takeover database (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        print(f"Removing takeover email with ID: {email_id}")
        takeover_email = TakeoverEmail.query.get(email_id)
        
        if not takeover_email:
            print(f"Takeover email not found: {email_id}")
            return jsonify({'error': 'Takeover email not found'}), 404
            
        print(f"Found takeover email: {takeover_email.email_address}")
        
        # Store email address for response
        email_address = takeover_email.email_address
        
        # Delete from database
        db.session.delete(takeover_email)
        db.session.commit()
        
        print(f"Successfully removed takeover email: {email_address}")
        
        return jsonify({
            'success': True,
            'message': f'Successfully removed {email_address} from takeover database',
            'email_address': email_address,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        print(f"Error removing takeover email: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/contacts', methods=['POST'])
@login_required
def save_contact_form():
    """Save contact form data for interested users (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        username = data.get('username')
        email = data.get('email')
        proposed_price = data.get('proposed_price')
        notes = data.get('notes', '')
        
        if not all([user_id, username, email]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Create contact record (you can extend this to save to database)
        contact_data = {
            'user_id': user_id,
            'username': username,
            'email': email,
            'proposed_price': proposed_price,
            'notes': notes,
            'created_at': datetime.now().isoformat(),
            'created_by': current_user.id
        }
        
        # Save to a contacts file (you can modify this to use database)
        contacts_file = 'contacts.json'
        contacts = []
        
        if os.path.exists(contacts_file):
            try:
                with open(contacts_file, 'r') as f:
                    contacts = json.load(f)
            except:
                contacts = []
        
        # Check if contact already exists
        existing_contact = next((c for c in contacts if c.get('user_id') == user_id), None)
        if existing_contact:
            # Update existing contact
            existing_contact.update(contact_data)
        else:
            # Add new contact
            contacts.append(contact_data)
        
        with open(contacts_file, 'w') as f:
            json.dump(contacts, f, indent=4)
        
        return jsonify({
            'success': True,
            'message': 'Contact saved successfully',
            'contact': contact_data
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/contacts', methods=['GET'])
@login_required
def get_contacts():
    """Get all saved contacts (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        contacts_file = 'contacts.json'
        contacts = []
        
        if os.path.exists(contacts_file):
            try:
                with open(contacts_file, 'r') as f:
                    contacts = json.load(f)
            except:
                contacts = []
        
        return jsonify({
            'success': True,
            'contacts': contacts
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/interest-analysis', methods=['GET'])
@login_required
def get_user_own_interest_analysis():
    """Get interest analysis for the current user's contacts"""
    try:
        user_id = current_user.id
        
        # Get all email addresses that have conversation history
        email_addresses = brand_bot.get_all_email_addresses(user_id)
        
        if not email_addresses:
            # Return empty results when no real contacts exist
            return jsonify({
                'success': True,
                'contacts': [],
                'stats': {
                    'interested': 0,
                    'not_interested': 0,
                    'unknown': 0,
                    'total': 0
                }
            })
        
        # Analyze each email address
        contacts_data = []
        for email in email_addresses:
            # Get conversations for this email
            conversations = brand_bot.get_conversations_by_email(user_id, email)
            
            # Analyze interest for this email
            interest_analysis = brand_bot.analyze_interest_by_email(user_id, email)
            
            # Extract name from email
            import re
            name = email.split('@')[0] if '@' in email else email
            name = re.sub(r'[^a-zA-Z0-9\s]', '', name).strip()
            if not name:
                name = f"Contact {len(contacts_data) + 1}"
            
            contact_data = {
                'id': hash(email) % 1000000,
                'name': name,
                'email': email,
                'interest_status': interest_analysis['status'],
                'confidence': interest_analysis['confidence'],
                'reason': interest_analysis['reason'],
                'last_analyzed': interest_analysis['last_analyzed'],
                'indicators': interest_analysis.get('indicators', {'positive': 0, 'negative': 0}),
                'conversation_count': len(conversations)
            }
            contacts_data.append(contact_data)
        
        # Calculate stats
        interested_count = len([c for c in contacts_data if c['interest_status'] == 'interested'])
        not_interested_count = len([c for c in contacts_data if c['interest_status'] == 'not_interested'])
        unknown_count = len([c for c in contacts_data if c['interest_status'] == 'unknown'])
        
        return jsonify({
            'success': True,
            'contacts': contacts_data,
            'stats': {
                'interested': interested_count,
                'not_interested': not_interested_count,
                'unknown': unknown_count,
                'total': len(contacts_data)
            }
        })
    except Exception as e:
        print(f"Error in user interest analysis: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/contacts', methods=['POST'])
@login_required
def save_user_contact():
    """Save contact form data for the current user"""
    try:
        data = request.get_json()
        contact_name = data.get('contact_name')
        email = data.get('email')
        proposed_price = data.get('proposed_price')
        notes = data.get('notes', '')
        
        if not all([contact_name, email]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Create contact record for the current user
        contact_data = {
            'user_id': current_user.id,
            'contact_name': contact_name,
            'email': email,
            'proposed_price': proposed_price,
            'notes': notes,
            'created_at': datetime.now().isoformat()
        }
        
        # Save to user-specific contacts file
        contacts_file = f'user_contacts_{current_user.id}.json'
        contacts = []
        
        if os.path.exists(contacts_file):
            try:
                with open(contacts_file, 'r') as f:
                    contacts = json.load(f)
            except:
                contacts = []
        
        # Check if contact already exists
        existing_contact = next((c for c in contacts if c.get('email') == email), None)
        if existing_contact:
            # Update existing contact
            existing_contact.update(contact_data)
        else:
            # Add new contact
            contacts.append(contact_data)
        
        with open(contacts_file, 'w') as f:
            json.dump(contacts, f, indent=4)
        
        return jsonify({
            'success': True,
            'message': 'Contact saved successfully',
            'contact': contact_data
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/contacts/<email>', methods=['DELETE'])
@login_required
def delete_user_contact(email):
    """Delete a contact for the current user"""
    try:
        # Delete all conversations for this email address
        success = brand_bot.delete_conversations_by_email(current_user.id, email)
        
        if success:
            print(f"✅ Successfully deleted contact {email} for user {current_user.id}")
            return jsonify({
                'success': True,
                'message': f'Contact {email} deleted successfully'
            })
        else:
            print(f"❌ Failed to delete contact {email} for user {current_user.id}")
            return jsonify({
                'success': False,
                'message': f'Failed to delete contact {email}'
            }), 400
            
    except Exception as e:
        print(f"Error deleting contact: {e}")
        return jsonify({'error': str(e)}), 500

class PasswordResetToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    token = db.Column(db.String(128), unique=True, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)

class Email(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    sender = db.Column(db.String(200))
    subject = db.Column(db.String(500))
    snippet = db.Column(db.String(1000))
    date = db.Column(db.DateTime)
    message_id = db.Column(db.String(200), unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'sender': self.sender,
            'subject': self.subject,
            'snippet': self.snippet,
            'date': self.date.isoformat() if self.date else None,
            'message_id': self.message_id
        }

class TakeoverEmail(db.Model):
    """Model for emails that have been taken over by admin"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # Can be NULL for external emails
    email_address = db.Column(db.String(200), nullable=False)
    user_name = db.Column(db.String(100))
    original_status = db.Column(db.String(50))  # interested, not_interested, unknown
    taken_over_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # admin who took over
    taken_over_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'email_address': self.email_address,
            'user_name': self.user_name,
            'original_status': self.original_status,
            'taken_over_by': self.taken_over_by,
            'taken_over_at': self.taken_over_at.isoformat() if self.taken_over_at else None,
            'notes': self.notes
        }

@app.route('/api/forgot-password', methods=['POST'])
def forgot_password():
    data = request.json
    email = data.get('email')
    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({'error': 'No user with that email'}), 404
    # Generate token
    token = secrets.token_urlsafe(32)
    expires_at = datetime.utcnow() + timedelta(hours=1)
    reset_token = PasswordResetToken(user_id=user.id, token=token, expires_at=expires_at)
    db.session.add(reset_token)
    db.session.commit()
    # Send email
    reset_url = f"http://localhost:5000/reset-password?token={token}"
    try:
        msg = Message('Password Reset Request', recipients=[email])
        msg.body = f'Click the link to reset your password: {reset_url}'
        mail.send(msg)
    except Exception as e:
        print(f"Failed to send email: {e}")
    return jsonify({'message': 'Password reset link sent (check your email)'}), 200

@app.route('/api/reset-password', methods=['POST'])
def reset_password():
    data = request.json
    token = data.get('token')
    new_password = data.get('password')
    if not token or not new_password:
        return jsonify({'error': 'Missing token or password'}), 400
    reset_token = PasswordResetToken.query.filter_by(token=token).first()
    if not reset_token or reset_token.expires_at < datetime.utcnow():
        return jsonify({'error': 'Invalid or expired token'}), 400
    user = User.query.get(reset_token.user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    user.password = bcrypt.generate_password_hash(new_password).decode('utf-8')
    db.session.delete(reset_token)
    db.session.commit()
    return jsonify({'message': 'Password has been reset successfully'})

@app.route('/api/emails', methods=['GET'])
@login_required
def get_emails():
    # Return the 10 most recent emails for the current user
    emails = Email.query.filter_by(user_id=current_user.id).order_by(Email.date.desc()).limit(10).all()
    
    if not emails:
        # Return empty list instead of sample emails
        return jsonify([])
    
    return jsonify([email.to_dict() for email in emails])

# Instantiate the bot once
brand_bot = EnhancedBrandBot()

def is_email_in_takeover_database(email_address):
    """Check if an email address exists in the takeover database"""
    try:
        takeover_email = TakeoverEmail.query.filter_by(email_address=email_address).first()
        return takeover_email is not None
    except Exception as e:
        print(f"Error checking takeover database: {e}")
        return False

# Replace the old OpenAI reply function
def generate_reply_with_openai(subject, snippet, user=None, email_address=None):
    # Use the bot's AI response for email answering with PDF context
    pdf_content = None
    user_id = None
    if user:
        user_id = user.id
        if user.pdf_content:
            pdf_content = user.pdf_content
            print(f"📄 Using PDF content for user {user.email}: {len(pdf_content)} characters")
        else:
            print(f"📄 No PDF content available for user {user.email}")
    else:
        print(f"📄 No PDF content available for user unknown")
    
    return brand_bot.generate_email_reply_with_pdf_context(subject, snippet, pdf_content, user_id, email_address)

def send_email_reply(user, to_addr, subject, reply_body):
    try:
        # Clean the reply body to handle special characters
        cleaned_reply = reply_body.encode('utf-8', errors='ignore').decode('utf-8')
        
        # Create message with proper encoding
        msg = MIMEText(cleaned_reply, 'plain', 'utf-8')
        msg['Subject'] = f"Re: {subject}"
        msg['From'] = user.gmail
        msg['To'] = to_addr
        
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(user.gmail, user.gmail_app_password)
            server.sendmail(user.gmail, [to_addr], msg.as_string())
        print(f"✅ Sent reply to {to_addr}")
    except Exception as e:
        print(f"❌ Failed to send reply: {e}")
        # Try with ASCII fallback
        try:
            cleaned_reply_ascii = reply_body.encode('ascii', errors='ignore').decode('ascii')
            msg = MIMEText(cleaned_reply_ascii, 'plain', 'ascii')
            msg['Subject'] = f"Re: {subject}"
            msg['From'] = user.gmail
            msg['To'] = to_addr
            
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
                server.login(user.gmail, user.gmail_app_password)
                server.sendmail(user.gmail, [to_addr], msg.as_string())
            print(f"✅ Sent reply to {to_addr} (ASCII fallback)")
        except Exception as e2:
            print(f"❌ Failed to send reply even with ASCII fallback: {e2}")

def fetch_and_store_emails_for_user(user):
    if not user.gmail or not user.gmail_app_password:
        return
    try:
        mail = imaplib.IMAP4_SSL('imap.gmail.com')
        mail.login(user.gmail, user.gmail_app_password)
        mail.select('inbox')
        status, messages = mail.search(None, 'ALL')
        if status != 'OK':
            return
        message_ids = messages[0].split()[-10:]  # Only fetch last 10 emails for speed
        for msg_id in message_ids:
            status, msg_data = mail.fetch(msg_id, '(RFC822)')
            if status != 'OK':
                continue
            msg = pyemail.message_from_bytes(msg_data[0][1])
            subject, encoding = decode_header(msg.get('Subject'))[0]
            if isinstance(subject, bytes):
                subject = subject.decode(encoding or 'utf-8', errors='ignore')
            sender, encoding = decode_header(msg.get('From'))[0]
            if isinstance(sender, bytes):
                sender = sender.decode(encoding or 'utf-8', errors='ignore')
            date = msg.get('Date')
            message_id = msg.get('Message-ID')
            snippet = ''
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == 'text/plain' and part.get_payload(decode=True):
                        snippet = part.get_payload(decode=True).decode(errors='ignore')[:200]
                        break
            else:
                if msg.get_payload(decode=True):
                    snippet = msg.get_payload(decode=True).decode(errors='ignore')[:200]
            # Avoid duplicates by message_id
            if not Email.query.filter_by(message_id=message_id, user_id=user.id).first():
                try:
                    dt = None
                    if date:
                        from email.utils import parsedate_to_datetime
                        dt = parsedate_to_datetime(date)
                    new_email = Email(
                        user_id=user.id,
                        sender=sender,
                        subject=subject,
                        snippet=snippet,
                        date=dt,
                        message_id=message_id
                    )
                    db.session.add(new_email)
                    db.session.commit()
                    # --- Generate and send reply ---
                    # Extract just the email address from sender
                    match = re.search(r'<(.+?)>', sender)
                    to_addr = match.group(1) if match else sender
                    
                    print(f"📧 Processing email for user {user.email}")
                    print(f"📧 Subject: {subject}")
                    print(f"📧 Snippet: {snippet[:100]}...")
                    print(f"📧 User has PDF: {bool(user.pdf_content)}")
                    
                    # Check if this email is in takeover database
                    if is_email_in_takeover_database(to_addr):
                        print(f"🚫 This email {to_addr} exists in takeover database, so not replying")
                        continue
                    
                    reply_body = generate_reply_with_openai(subject, snippet, user, to_addr)
                    print(f"📧 Generated reply: {reply_body[:200]}...")
                    
                    send_email_reply(user, to_addr, subject, reply_body)
                except Exception as e:
                    db.session.rollback()
                    print(f"Error saving or replying to email: {e}")
        mail.logout()
    except Exception as e:
        print(f"Failed to fetch emails for {user.email}: {e}")

def background_email_fetcher():
    with app.app_context():
        while True:
            users = User.query.filter(User.gmail.isnot(None), User.gmail_app_password.isnot(None)).all()
            for user in users:
                fetch_and_store_emails_for_user(user)
            time.sleep(5)

# Initialize database and create admin user
def initialize_database():
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Create admin user if it doesn't exist
        admin_user = User.query.filter_by(email='admin@gmail.com').first()
        if not admin_user:
            admin_user = User(
                email='admin@gmail.com',
                password=bcrypt.generate_password_hash('admin123').decode('utf-8'),
                is_admin=True,
                instagram='admin',
                tiktok='',
                youtube=''
            )
            db.session.add(admin_user)
            db.session.commit()
            print('Admin user created: admin@gmail.com / admin123')
        else:
            # Fix existing admin user's password if it's corrupted
            try:
                # Try to verify the current password
                bcrypt.check_password_hash(admin_user.password, 'admin123')
                print('Admin user already exists with correct password.')
            except ValueError:
                # Password hash is corrupted, fix it
                admin_user.password = bcrypt.generate_password_hash('admin123').decode('utf-8')
                db.session.commit()
                print('Admin user password fixed: admin@gmail.com / admin123')

# Start the background thread when the app starts
threading.Thread(target=background_email_fetcher, daemon=True).start()

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.route('/settings')
@login_required
def settings_page():
    return render_template('settings.html')

@app.route('/api/user/migrate-conversations', methods=['POST'])
@login_required
def migrate_conversations():
    """Migrate conversation history to new email-based structure"""
    try:
        user_id = current_user.id
        success = brand_bot.migrate_to_email_based_structure(user_id)
        
        if success:
            return jsonify({"success": True, "message": "Conversation history migrated successfully"})
        else:
            return jsonify({"success": False, "message": "Failed to migrate conversation history"}), 500
            
    except Exception as e:
        print(f"Error migrating conversations: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/users/<int:user_id>/migrate-conversations', methods=['POST'])
@login_required
def migrate_user_conversations(user_id):
    """Admin endpoint to migrate conversation history for a specific user"""
    if not current_user.is_admin:
        return jsonify({"success": False, "message": "Admin access required"}), 403
    
    try:
        success = brand_bot.migrate_to_email_based_structure(user_id)
        
        if success:
            return jsonify({"success": True, "message": f"Conversation history migrated successfully for user {user_id}"})
        else:
            return jsonify({"success": False, "message": f"Failed to migrate conversation history for user {user_id}"}), 500
            
    except Exception as e:
        print(f"Error migrating conversations for user {user_id}: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/emails/interest-analysis', methods=['GET'])
@login_required
def get_all_emails_interest_analysis():
    """Get interest analysis for all email addresses across all users (admin only)"""
    if not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        users = User.query.all()
        all_emails_data = []
        
        for user in users:
            # Get all email addresses that have conversation history for this user
            email_addresses = brand_bot.get_all_email_addresses(user.id)
            
            for email in email_addresses:
                # Get conversations for this email
                conversations = brand_bot.get_conversations_by_email(user.id, email)
                
                # Analyze interest for this email
                interest_analysis = brand_bot.analyze_interest_by_email(user.id, email)
                
                # Extract name from email
                import re
                name = email.split('@')[0] if '@' in email else email
                name = re.sub(r'[^a-zA-Z0-9\s]', '', name).strip()
                if not name:
                    name = f"Contact {len(all_emails_data) + 1}"
                
                email_data = {
                    'id': hash(email) % 1000000,
                    'name': name,
                    'email': email,
                    'user_id': user.id,
                    'user_name': user.name or user.email,
                    'interest_status': interest_analysis['status'],
                    'confidence': interest_analysis['confidence'],
                    'reason': interest_analysis['reason'],
                    'last_analyzed': interest_analysis['last_analyzed'],
                    'indicators': interest_analysis.get('indicators', {'positive': 0, 'negative': 0}),
                    'conversation_count': len(conversations)
                }
                all_emails_data.append(email_data)
        
        # Calculate stats
        interested_count = len([e for e in all_emails_data if e['interest_status'] == 'interested'])
        not_interested_count = len([e for e in all_emails_data if e['interest_status'] == 'not_interested'])
        unknown_count = len([e for e in all_emails_data if e['interest_status'] == 'unknown'])
        
        return jsonify({
            'success': True,
            'emails': all_emails_data,
            'stats': {
                'interested': interested_count,
                'not_interested': not_interested_count,
                'unknown': unknown_count,
                'total': len(all_emails_data)
            },
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        print(f"Error in admin emails interest analysis: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Initialize database and create admin user
    initialize_database()
    
    # Create upload folder if it doesn't exist
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    
    # Create PDFs directory if it doesn't exist
    if not os.path.exists('pdfs'):
        os.makedirs('pdfs')
    
    app.run(debug=True)
# Note: For full security, add CSRF protection (Flask-WTF), HTTPS, secure cookies, and user email verification in production. 