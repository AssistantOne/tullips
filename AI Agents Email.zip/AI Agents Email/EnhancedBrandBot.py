import os
import PyPDF2
import json
import shutil
from pathlib import Path
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnableWithMessageHistory
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.chat_history import BaseChatMessageHistory
import re
from datetime import datetime, timedelta
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# Load environment variables
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
EMAIL_USER = os.getenv("EMAIL_USER")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))

class EnhancedBrandBot:
    def __init__(self):
        """Initialize the Enhanced Brand Collaboration Bot"""
        self.pdf_content = ""
        self.loaded_pdfs = []
        self.conversation_stage = "greeting"
        self.brand_name = ""
        self.brand_interested = False
        self.services_discussed = False
        
        # Enhanced client information
        self.client_info = {
            "brand_name": "",
            "contact_person": "",
            "email": "",
            "phone": "",
            "company": "",
            "industry": "",
            "service_requested": "",
            "platform_preference": "",
            "budget": "",
            "timeline": "",
            "special_requirements": "",
            "contract_value": 0,
            "agreement_reached": False
        }
        
        # Contract tracking variables
        self.contracts_done = 0
        self.missed_contracts = 0
        self.pending_contracts = 0
        self.stats_file = "contract_stats.json"
        self.contracts_folder = "contracts"
        self.leads_folder = "leads"
        
        # Create necessary folders
        os.makedirs(self.contracts_folder, exist_ok=True)
        os.makedirs(self.leads_folder, exist_ok=True)
        os.makedirs("pdfs", exist_ok=True)
        os.makedirs("conversation_histories", exist_ok=True)
        
        # User-specific conversation histories
        self.user_conversations = {}  # Store conversation histories per user
        
        # Enhanced service pricing with detailed descriptions
        self.services = {
            "instagram_post": {
                "name": "Instagram Post", 
                "price": 150, 
                "description": "1 professional image + engaging caption + hashtags + story mention",
                "deliverables": ["High-quality image/graphic", "SEO-optimized caption", "Relevant hashtags", "Story mention", "Performance report"],
                "timeline": "5-7 days"
            },
            "instagram_reel": {
                "name": "Instagram Reel", 
                "price": 200, 
                "description": "15–30 sec engaging video content",
                "deliverables": ["Professional video editing", "Trending audio/music", "Captions/text overlay", "Hashtag strategy", "Performance analytics"],
                "timeline": "7-10 days"
            },
            "instagram_story": {
                "name": "Instagram Story", 
                "price": 100, 
                "description": "3 interactive slides with swipe-ups",
                "deliverables": ["3 story slides", "Interactive elements", "Swipe-up links", "24-hour highlights", "Engagement report"],
                "timeline": "3-5 days"
            },
            "tiktok_video": {
                "name": "TikTok Video", 
                "price": 180, 
                "description": "15–30 sec viral-style content",
                "deliverables": ["Trending format video", "Original sound/music", "Hashtag optimization", "Cross-platform posting", "Engagement metrics"],
                "timeline": "5-7 days"
            },
            "content_bundle": {
                "name": "Content Bundle", 
                "price": 400, 
                "description": "Complete social media package",
                "deliverables": ["1 Instagram Post", "1 Instagram Story", "1 Instagram Reel", "Cross-promotion", "Comprehensive analytics"],
                "timeline": "10-14 days"
            },
            "ugc_modeling": {
                "name": "UGC/Product Modeling", 
                "price": 250, 
                "description": "5 professional product images",
                "deliverables": ["5 styled product photos", "Multiple angles/settings", "High-resolution files", "Usage rights", "Raw + edited versions"],
                "timeline": "7-10 days"
            },
            "monthly_package": {
                "name": "Monthly Brand Ambassador Package", 
                "price": 1000, 
                "description": "Complete monthly brand partnership",
                "deliverables": ["4 Instagram Posts", "4 Instagram Stories", "2 Instagram Reels", "Monthly strategy call", "Detailed performance report"],
                "timeline": "30 days"
            }
        }
        
        # Initialize AI
        if OPENAI_API_KEY:
            self.llm = ChatOpenAI(
                temperature=0.7,
                openai_api_key=OPENAI_API_KEY,
                model="gpt-3.5-turbo"
            )
            # Simple conversation history for now
            self.conversation_history_messages = []
            print("🤖 AI system initialized")
        else:
            self.llm = None
            print("❌ AI system not available without API key")
        
        self.load_all_pdfs()
        self.history_file = "conversation_history.json"
        self.conversation_history = self.load_conversation_history()
        self.load_contract_stats()

    def load_all_pdfs(self, specific_path=None):
        """Enhanced PDF loading - supports any PDF from any location"""
        pdf_files = []
        
        if specific_path:
            # Handle specific file path
            pdf_path = Path(specific_path)
            if pdf_path.exists() and pdf_path.suffix.lower() == '.pdf':
                pdf_files = [pdf_path]
                print(f"📚 Loading specific PDF: {pdf_path.name}")
            else:
                print(f"❌ PDF file not found: {pdf_path}")
                return False
        else:
            # Look in multiple locations
            search_locations = [
                Path("."),  # Current directory
                Path("pdfs"),  # PDFs folder
                Path("documents"),  # Documents folder
                Path("files"),  # Files folder
            ]
            
            for location in search_locations:
                if location.exists():
                    found_pdfs = list(location.glob("*.pdf"))
                    pdf_files.extend(found_pdfs)
                    if found_pdfs:
                        print(f"📁 Found {len(found_pdfs)} PDFs in {location}")
            
            if not pdf_files:
                print("📄 No PDF files found. You can:")
                print("  1. Place PDFs in current directory")
                print("  2. Place PDFs in 'pdfs/' folder")  
                print("  3. Use load_specific_pdf('path/to/file.pdf')")
                return False
        
        # Load all found PDFs
        successful_loads = 0
        for pdf_file in pdf_files:
            if self.load_single_pdf(pdf_file):
                successful_loads += 1
        
        if successful_loads > 0:
            print(f"\n🎉 Successfully loaded {successful_loads} PDF files!")
            print(f"📊 Total content: {len(self.pdf_content)} characters")
            return True
        return False

    def load_specific_pdf(self, pdf_path):
        """Load a specific PDF file"""
        return self.load_all_pdfs(pdf_path)

    def load_single_pdf(self, pdf_file):
        """Load a single PDF file with error handling"""
        try:
            print(f"📖 Loading {pdf_file.name}...")
            
            with open(pdf_file, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                pdf_text = ""
                
                for page_num, page in enumerate(pdf_reader.pages, 1):
                    try:
                        page_text = page.extract_text()
                        pdf_text += f"\n--- Page {page_num} of {pdf_file.name} ---\n"
                        pdf_text += page_text + "\n"
                    except Exception as e:
                        print(f"⚠️ Warning: Could not read page {page_num} of {pdf_file.name}: {e}")
                        continue
                
                if pdf_text.strip():
                    self.pdf_content += f"\n\n=== CONTENT FROM {pdf_file.name.upper()} ===\n"
                    self.pdf_content += pdf_text
                    self.loaded_pdfs.append(pdf_file.name)
                    
                    print(f"✅ Loaded {pdf_file.name} ({len(pdf_text)} characters, {len(pdf_reader.pages)} pages)")
                    return True
                else:
                    print(f"❌ No readable content found in {pdf_file.name}")
                    return False
                    
        except Exception as e:
            print(f"❌ Error loading {pdf_file.name}: {str(e)}")
            return False

    def generate_contract_pdf(self, client_info, service_details):
        """Generate a professional contract PDF"""
        contract_id = f"CONTR_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        filename = f"{self.contracts_folder}/contract_{client_info['brand_name'].replace(' ', '')}{contract_id}.pdf"
        # Create PDF document
        doc = SimpleDocTemplate(filename, pagesize=letter, topMargin=1*inch)
        story = []
        styles = getSampleStyleSheet()
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=18,
            textColor=colors.darkblue,
            spaceAfter=30,
            alignment=1  # Center alignment
        )
        header_style = ParagraphStyle(
            'CustomHeader',
            parent=styles['Heading2'],
            fontSize=14,
            textColor=colors.darkblue,
            spaceAfter=12
        )
        # Title
        story.append(Paragraph("BRAND COLLABORATION AGREEMENT", title_style))
        story.append(Spacer(1, 20))
        # Contract details
        story.append(Paragraph(f"Contract ID: {contract_id}", styles['Normal']))
        story.append(Paragraph(f"Date: {datetime.now().strftime('%B %d, %Y')}", styles['Normal']))
        story.append(Spacer(1, 20))
        # Parties section
        story.append(Paragraph("PARTIES", header_style))
        # Service provider info
        provider_info = [
            ["Service Provider:", "Your Company Name"],
            ["Address:", "Your Company Address"],
            ["Email:", "your-email@company.com"],
            ["Phone:", "Your Phone Number"]
        ]
        provider_table = Table(provider_info, colWidths=[2*inch, 4*inch])
        provider_table.setStyle(TableStyle([
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,-1), 10),
            ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ]))
        story.append(provider_table)
        story.append(Spacer(1, 15))
        # Client info
        client_data = [
            ["Client:", client_info.get('brand_name', 'N/A')],
            ["Contact Person:", client_info.get('contact_person', 'N/A')],
            ["Email:", client_info.get('email', 'N/A')],
            ["Phone:", client_info.get('phone', 'N/A')],
            ["Company:", client_info.get('company', 'N/A')]
        ]
        client_table = Table(client_data, colWidths=[2*inch, 4*inch])
        client_table.setStyle(TableStyle([
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,-1), 10),
            ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ]))
        story.append(client_table)
        story.append(Spacer(1, 20))
        # Service details
        story.append(Paragraph("SERVICE DETAILS", header_style))
        service_key = client_info.get('service_requested', '')
        if service_key in self.services:
            service = self.services[service_key]
            service_data = [
                ["Service:", service['name']],
                ["Description:", service['description']],
                ["Price:", f"${service['price']}"],
                ["Timeline:", service['timeline']],
                ["Platform:", client_info.get('platform_preference', 'Instagram')]
            ]
            service_table = Table(service_data, colWidths=[2*inch, 4*inch])
            service_table.setStyle(TableStyle([
                ('ALIGN', (0,0), (-1,-1), 'LEFT'),
                ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
                ('FONTSIZE', (0,0), (-1,-1), 10),
                ('BOTTOMPADDING', (0,0), (-1,-1), 6),
                ('GRID', (0,0), (-1,-1), 1, colors.lightgrey),
            ]))
            story.append(service_table)
            story.append(Spacer(1, 15))
            # Deliverables
            story.append(Paragraph("DELIVERABLES", header_style))
            for i, deliverable in enumerate(service['deliverables'], 1):
                story.append(Paragraph(f"{i}. {deliverable}", styles['Normal']))
            story.append(Spacer(1, 15))
        # Payment terms
        story.append(Paragraph("PAYMENT TERMS", header_style))
        payment_terms = [
            "50% deposit required upon signing this agreement",
            "Remaining 50% due upon content approval and before posting",
            "Payment methods: Bank transfer, PayPal, or as agreed",
            "Late payment fee: 5% per month on overdue amounts"
        ]
        for term in payment_terms:
            story.append(Paragraph(f"• {term}", styles['Normal']))
        story.append(Spacer(1, 15))
        # Terms and conditions
        story.append(Paragraph("TERMS & CONDITIONS", header_style))
        terms = [
            "Content will be created according to brand guidelines provided",
            "Two rounds of revisions included in the price",
            "Client retains rights to approved content for their marketing use",
            "Influencer retains rights to keep content on their social media",
            "Content will remain live for minimum 6 months unless otherwise agreed",
            "This agreement is governed by local jurisdiction laws"
        ]
        for term in terms:
            story.append(Paragraph(f"• {term}", styles['Normal']))
        story.append(Spacer(1, 30))
        # Signature section
        story.append(Paragraph("SIGNATURES", header_style))
        signature_data = [
            ["Service Provider Signature:", "Date:"],
            ["", ""],
            ["", ""],
            ["Client Signature:", "Date:"],
            ["", ""],
            ["", ""]
        ]
        signature_table = Table(signature_data, colWidths=[4*inch, 2*inch])
        signature_table.setStyle(TableStyle([
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,-1), 10),
            ('LINEBELOW', (0,1), (0,1), 1, colors.black),
            ('LINEBELOW', (1,1), (1,1), 1, colors.black),
            ('LINEBELOW', (0,4), (0,4), 1, colors.black),
            ('LINEBELOW', (1,4), (1,4), 1, colors.black),
        ]))
        story.append(signature_table)
        # Build PDF
        try:
            doc.build(story)
            print(f"✅ Contract generated: {filename}")
            return filename
        except Exception as e:
            print(f"❌ Error generating contract: {e}")
            return None

    def save_lead_info(self, client_info):
        """Save lead information to JSON file"""
        lead_id = f"LEAD_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        filename = f"{self.leads_folder}/lead_{client_info.get('brand_name', 'unknown').replace(' ', '')}{lead_id}.json"
        try:
            with open(filename, 'w') as f:
                json.dump(client_info, f, indent=4)
            print(f"✅ Lead info saved to {filename}")
            return True
        except Exception as e:
            print(f"❌ Error saving lead info: {e}")
            return False

    def send_contract_email(self, client_email, contract_path, client_info):
        """Send contract via email"""
        msg = MIMEMultipart()
        msg['From'] = EMAIL_USER
        msg['To'] = client_email
        msg['Subject'] = f"Your Brand Collaboration Agreement - {client_info.get('brand_name', 'Your Brand')}"

        # Attach contract PDF
        with open(contract_path, 'rb') as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename="{os.path.basename(contract_path)}"')
            msg.attach(part)

        # Attach a cover letter (optional, but good practice)
        cover_letter = f"""
Dear {client_info.get('contact_person', 'Client')},

Thank you for your interest in collaborating with us. This email serves as a formal agreement for our brand collaboration.

**Contract Details:**
- Contract ID: {contract_path.split('_')[-1].replace('.pdf', '')}
- Date: {datetime.now().strftime('%B %d, %Y')}
- Service: {client_info.get('service_requested', 'N/A')}
- Total Value: ${client_info.get('contract_value', 'N/A')}

**Your Responsibilities:**
- Provide all necessary assets (images, videos, text, etc.) for the agreed service.
- Review and approve the final content within 24 hours of receipt.
- Pay the agreed deposit and remaining balance as per the payment terms.

**Our Responsibilities:**
- Create the agreed content based on your brand guidelines.
- Provide two rounds of revisions.
- Ensure timely delivery of all deliverables.

Please review the attached contract and let us know if you have any questions or require further clarification.

Best regards,
Your Company Name
"""
        msg.attach(MIMEText(cover_letter, 'plain'))

        try:
            server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
            server.starttls()
            server.login(EMAIL_USER, EMAIL_PASSWORD)
            server.send_message(msg)
            server.quit()
            print(f"✅ Contract email sent to {client_email}")
            return True
        except Exception as e:
            print(f"❌ Error sending contract email: {e}")
            return False

    def process_agreement(self, client_info):
        """Process when client agrees to collaboration"""
        self.client_info = client_info
        self.brand_interested = True
        self.conversation_stage = "service_selection"
        self.services_discussed = False
        print(f"✅ Client {client_info['brand_name']} agreed to collaboration!")
        self.generate_contract_pdf(client_info, self.services[client_info['service_requested']])
        self.send_contract_email(client_info['email'], self.generate_contract_pdf(client_info, self.services[client_info['service_requested']]), client_info)
        self.increment_contracts_done()
        self.save_contract_stats()
        self.save_conversation_history()
        self.show_services_menu()

    def collect_client_info(self, user_input):
        """Extract and collect client information from conversation"""
        if self.conversation_stage == "greeting":
            if "hello" in user_input.lower() or "hi" in user_input.lower():
                self.conversation_stage = "introduction"
                return "Hello! I'm the Enhanced Brand Collaboration Bot. How can I assist you today?"
            elif "brand" in user_input.lower() and "interested" in user_input.lower():
                self.conversation_stage = "brand_name"
                return "Could you please tell me the name of your brand?"
            else:
                return "Hello! I'm the Enhanced Brand Collaboration Bot. How can I assist you today?"

        elif self.conversation_stage == "brand_name":
            self.brand_name = user_input
            self.conversation_stage = "introduction"
            return f"Great! I'll help you with {self.brand_name}. How can I assist you today?"

        elif self.conversation_stage == "introduction":
            if "service" in user_input.lower() and "interested" in user_input.lower():
                self.conversation_stage = "service_selection"
                return "I see you're interested in our services. What specific social media services are you looking for?"
            elif "budget" in user_input.lower() and "timeline" in user_input.lower():
                self.conversation_stage = "budget_timeline"
                return "Could you please share your budget and timeline for this project?"
            elif "requirements" in user_input.lower() or "special" in user_input.lower():
                self.conversation_stage = "special_requirements"
                return "I understand you have some specific requirements. Could you please elaborate?"
            else:
                return "I see. I'm here to help you with your social media strategy. What can I assist you with?"

        elif self.conversation_stage == "service_selection":
            if "instagram" in user_input.lower() and "post" in user_input.lower():
                self.client_info['service_requested'] = "instagram_post"
                self.services_discussed = True
                self.conversation_stage = "service_details"
                return "Great! You've chosen Instagram Post. What's the budget for this service?"
            elif "instagram" in user_input.lower() and "reel" in user_input.lower():
                self.client_info['service_requested'] = "instagram_reel"
                self.services_discussed = True
                self.conversation_stage = "service_details"
                return "Perfect! You've chosen Instagram Reel. What's the budget for this service?"
            elif "instagram" in user_input.lower() and "story" in user_input.lower():
                self.client_info['service_requested'] = "instagram_story"
                self.services_discussed = True
                self.conversation_stage = "service_details"
                return "Awesome! You've chosen Instagram Story. What's the budget for this service?"
            elif "tiktok" in user_input.lower() and "video" in user_input.lower():
                self.client_info['service_requested'] = "tiktok_video"
                self.services_discussed = True
                self.conversation_stage = "service_details"
                return "Fantastic! You've chosen TikTok Video. What's the budget for this service?"
            elif "content" in user_input.lower() and "bundle" in user_input.lower():
                self.client_info['service_requested'] = "content_bundle"
                self.services_discussed = True
                self.conversation_stage = "service_details"
                return "Excellent! You've chosen Content Bundle. What's the budget for this service?"
            elif "ugc" in user_input.lower() and "modeling" in user_input.lower():
                self.client_info['service_requested'] = "ugc_modeling"
                self.services_discussed = True
                self.conversation_stage = "service_details"
                return "Perfect! You've chosen UGC/Product Modeling. What's the budget for this service?"
            elif "monthly" in user_input.lower() and "package" in user_input.lower():
                self.client_info['service_requested'] = "monthly_package"
                self.services_discussed = True
                self.conversation_stage = "service_details"
                return "Great! You've chosen Monthly Brand Ambassador Package. What's the budget for this service?"
            else:
                return "I'm sorry, I didn't quite catch that. Could you please specify which service you're interested in?"

        elif self.conversation_stage == "service_details":
            if "budget" in user_input.lower() and "timeline" in user_input.lower():
                self.conversation_stage = "budget_timeline"
                return "Could you please share your budget and timeline for this project?"
            elif "requirements" in user_input.lower() or "special" in user_input.lower():
                self.conversation_stage = "special_requirements"
                return "I understand you have some specific requirements. Could you please elaborate?"
            else:
                # Attempt to extract budget and timeline from user_input
                match = re.search(r"budget\s*(\d+)", user_input, re.IGNORECASE)
                if match:
                    self.client_info['budget'] = int(match.group(1))
                    self.client_info['contract_value'] = int(match.group(1)) # Assuming budget is contract value for now
                    self.conversation_stage = "platform_preference"
                    return "Thank you for sharing your budget. What's your preferred platform for this service?"
                else:
                    return "I'm sorry, I didn't quite catch that. Could you please share your budget and timeline for this project?"

        elif self.conversation_stage == "budget_timeline":
            if "platform" in user_input.lower():
                self.conversation_stage = "platform_preference"
                return "What's your preferred platform for this service?"
            else:
                # Attempt to extract budget and timeline from user_input
                match = re.search(r"budget\s*(\d+)", user_input, re.IGNORECASE)
                if match:
                    self.client_info['budget'] = int(match.group(1))
                    self.client_info['contract_value'] = int(match.group(1)) # Assuming budget is contract value for now
                match = re.search(r"timeline\s*(\d+)", user_input, re.IGNORECASE)
                if match:
                    self.client_info['timeline'] = int(match.group(1))
                self.conversation_stage = "platform_preference"
                return "Thank you for sharing your budget and timeline. What's your preferred platform for this service?"

        elif self.conversation_stage == "platform_preference":
            self.client_info['platform_preference'] = user_input
            self.conversation_stage = "special_requirements"
            return "I understand you have some specific requirements. Could you please elaborate?"

        elif self.conversation_stage == "special_requirements":
            self.client_info['special_requirements'] = user_input
            self.conversation_stage = "agreement"
            return "Thank you for providing all the necessary information. I will now generate a contract for you. Please review it and let me know if you agree to the terms."

        elif self.conversation_stage == "agreement":
            if "yes" in user_input.lower() or "ok" in user_input.lower() or "i agree" in user_input.lower():
                self.client_info['agreement_reached'] = True
                self.process_agreement(self.client_info)
                return "Great! I've generated a contract for you. I've also sent it to your email address. Please review it and let me know if you have any questions or require further clarification."
            elif "no" in user_input.lower() or "i don't agree" in user_input.lower():
                self.client_info['agreement_reached'] = False
                self.conversation_stage = "greeting"
                return "I'm sorry to hear that. Would you like to try again or discuss a different service?"
            else:
                return "I'm sorry, I didn't quite catch that. Please type 'yes' or 'no' to agree or disagree to the terms."

        return "I'm sorry, I'm not sure how to respond to that."

    def detect_agreement(self, user_input):
        """Detect if client is ready to proceed with agreement"""
        if "yes" in user_input.lower() or "ok" in user_input.lower() or "i agree" in user_input.lower():
            return True
        elif "no" in user_input.lower() or "i don't agree" in user_input.lower():
            return False
        else:
            return None # Indicate inconclusive

    def generate_contextual_response(self, user_input: str) -> str:
        """Enhanced response generation with contract processing"""
        # This method is primarily for context, not direct interaction
        # It can be used to generate a response based on the current conversation stage
        # and the client's information.
        if self.conversation_stage == "greeting":
            if "hello" in user_input.lower() or "hi" in user_input.lower():
                return "Hello! I'm the Enhanced Brand Collaboration Bot. How can I assist you today?"
            elif "brand" in user_input.lower() and "interested" in user_input.lower():
                return "Could you please tell me the name of your brand?"
            else:
                return "Hello! I'm the Enhanced Brand Collaboration Bot. How can I assist you today?"

        elif self.conversation_stage == "brand_name":
            return f"Great! I'll help you with {self.brand_name}. How can I assist you today?"

        elif self.conversation_stage == "introduction":
            if "service" in user_input.lower() and "interested" in user_input.lower():
                return "I see you're interested in our services. What specific social media services are you looking for?"
            elif "budget" in user_input.lower() and "timeline" in user_input.lower():
                return "Could you please share your budget and timeline for this project?"
            elif "requirements" in user_input.lower() or "special" in user_input.lower():
                return "I understand you have some specific requirements. Could you please elaborate?"
            else:
                return "I see. I'm here to help you with your social media strategy. What can I assist you with?"

        elif self.conversation_stage == "service_selection":
            if "instagram" in user_input.lower() and "post" in user_input.lower():
                return "Great! You've chosen Instagram Post. What's the budget for this service?"
            elif "instagram" in user_input.lower() and "reel" in user_input.lower():
                return "Perfect! You've chosen Instagram Reel. What's the budget for this service?"
            elif "instagram" in user_input.lower() and "story" in user_input.lower():
                return "Awesome! You've chosen Instagram Story. What's the budget for this service?"
            elif "tiktok" in user_input.lower() and "video" in user_input.lower():
                return "Fantastic! You've chosen TikTok Video. What's the budget for this service?"
            elif "content" in user_input.lower() and "bundle" in user_input.lower():
                return "Excellent! You've chosen Content Bundle. What's the budget for this service?"
            elif "ugc" in user_input.lower() and "modeling" in user_input.lower():
                return "Perfect! You've chosen UGC/Product Modeling. What's the budget for this service?"
            elif "monthly" in user_input.lower() and "package" in user_input.lower():
                return "Great! You've chosen Monthly Brand Ambassador Package. What's the budget for this service?"
            else:
                return "I'm sorry, I didn't quite catch that. Could you please specify which service you're interested in?"

        elif self.conversation_stage == "service_details":
            if "budget" in user_input.lower() and "timeline" in user_input.lower():
                return "Could you please share your budget and timeline for this project?"
            elif "requirements" in user_input.lower() or "special" in user_input.lower():
                return "I understand you have some specific requirements. Could you please elaborate?"
            else:
                # Attempt to extract budget and timeline from user_input
                match = re.search(r"budget\s*(\d+)", user_input, re.IGNORECASE)
                if match:
                    return "Thank you for sharing your budget. What's your preferred platform for this service?"
                else:
                    return "I'm sorry, I didn't quite catch that. Could you please share your budget and timeline for this project?"

        elif self.conversation_stage == "budget_timeline":
            if "platform" in user_input.lower():
                return "What's your preferred platform for this service?"
            else:
                # Attempt to extract budget and timeline from user_input
                match = re.search(r"budget\s*(\d+)", user_input, re.IGNORECASE)
                if match:
                    return "Thank you for sharing your budget and timeline. What's your preferred platform for this service?"
                else:
                    return "I'm sorry, I didn't quite catch that. Could you please share your budget and timeline for this project?"

        elif self.conversation_stage == "platform_preference":
            return "I understand you have some specific requirements. Could you please elaborate?"

        elif self.conversation_stage == "special_requirements":
            return "I understand you have some specific requirements. Could you please elaborate?"

        elif self.conversation_stage == "agreement":
            if "yes" in user_input.lower() or "ok" in user_input.lower() or "i agree" in user_input.lower():
                return "Thank you for providing all the necessary information. I will now generate a contract for you. Please review it and let me know if you agree to the terms."
            elif "no" in user_input.lower() or "i don't agree" in user_input.lower():
                return "I'm sorry to hear that. Would you like to try again or discuss a different service?"
            else:
                return "I'm sorry, I didn't quite catch that. Please type 'yes' or 'no' to agree or disagree to the terms."

        return "I'm sorry, I'm not sure how to respond to that."

    def generate_ai_response(self, user_input: str) -> str:
        """Generate AI response with full context"""
        if self.llm:
            # Add user message to history
            self.conversation_history_messages.append(HumanMessage(content=user_input))
            
            # Generate response
            response = self.llm.invoke(self.conversation_history_messages)
            
            # Add AI response to history
            self.conversation_history_messages.append(AIMessage(content=response.content))
            
            return response.content
        else:
            return "AI system not available."

    def detect_user_interest(self, user_id):
        """Analyze user's conversation history to detect interest in collaboration using AI"""
        try:
            # Get the conversation history for user 2 (which contains the actual conversations)
            user_history = self.get_user_conversation_history(2)
            if not user_history:
                return {
                    "status": "unknown",
                    "confidence": 0.0,
                    "reason": "No conversation history available",
                    "last_analyzed": datetime.now().isoformat(),
                    "indicators": {"positive": 0, "negative": 0, "total": 0}
                }
            
            # Get recent conversations (last 10 for analysis)
            recent_conversations = user_history[-10:]
            
            # Combine all messages for analysis
            all_messages = " ".join([conv.get("message", "") for conv in recent_conversations])
            
            # Use AI-based analysis for more accurate detection
            try:
                ai_analysis = self.analyze_interest_with_ai(all_messages, recent_conversations)
                return {
                    "status": ai_analysis["status"],
                    "confidence": round(ai_analysis["confidence"], 2),
                    "reason": ai_analysis["reason"],
                    "last_analyzed": datetime.now().isoformat(),
                    "indicators": {
                        "positive": 1 if ai_analysis["status"] == "interested" else 0,
                        "negative": 1 if ai_analysis["status"] == "not_interested" else 0,
                        "total": 1 if ai_analysis["status"] != "unknown" else 0
                    }
                }
            except Exception as ai_error:
                print(f"AI analysis failed: {ai_error}")
                # Fallback to basic analysis
                return {
                    "status": "unknown",
                    "confidence": 0.0,
                    "reason": "AI analysis failed, fallback to basic analysis",
                    "last_analyzed": datetime.now().isoformat(),
                    "indicators": {"positive": 0, "negative": 0, "total": 0}
                }
            
        except Exception as e:
            print(f"Error detecting interest for user {user_id}: {e}")
            return {
                "status": "error",
                "confidence": 0.0,
                "reason": f"Error analyzing conversation: {str(e)}",
                "last_analyzed": datetime.now().isoformat(),
                "indicators": {"positive": 0, "negative": 0, "total": 0}
            }

    def analyze_interest_with_ai(self, all_messages, recent_conversations):
        """Use AI to analyze user interest in collaboration"""
        if not self.llm:
            return {"status": "unknown", "confidence": 0.0, "reason": "AI not available"}
        
        try:
            # Create a summary of recent conversations
            conversation_summary = ""
            for i, conv in enumerate(recent_conversations[-5:], 1):  # Last 5 conversations
                role = "Client" if conv.get("role") == "client" else "Manager"
                message = conv.get("message", "")[:100]  # First 100 chars
                conversation_summary += f"{i}. {role}: {message}...\n"
            
            prompt = f"""Analyze this conversation to determine if the client is interested in collaboration.

Conversation Summary:
{conversation_summary}

Full Messages: {all_messages[:1000]}

Based on the conversation, classify the client's interest level:

1. "interested" - Client shows clear interest in collaboration, asks about services, pricing, timeline, or expresses positive intent
2. "not_interested" - Client declines, says no, expresses disinterest, or shows negative intent
3. "unknown" - Unclear or neutral response

Respond with JSON format:
{{
    "status": "interested|not_interested|unknown",
    "confidence": 0.0-1.0,
    "reason": "Brief explanation of the classification"
}}"""

            response = self.llm.invoke([HumanMessage(content=prompt)])
            
            try:
                # Try to parse JSON response
                import json
                result = json.loads(response.content)
                return {
                    "status": result.get("status", "unknown"),
                    "confidence": float(result.get("confidence", 0.0)),
                    "reason": result.get("reason", "AI analysis completed")
                }
            except json.JSONDecodeError:
                # Fallback: parse text response
                content = response.content.lower()
                if "interested" in content and "not_interested" not in content:
                    return {"status": "interested", "confidence": 0.8, "reason": "AI detected interest"}
                elif "not_interested" in content:
                    return {"status": "not_interested", "confidence": 0.8, "reason": "AI detected disinterest"}
                else:
                    return {"status": "unknown", "confidence": 0.5, "reason": "AI analysis inconclusive"}
                    
        except Exception as e:
            print(f"Error in AI interest analysis: {e}")
            return {"status": "unknown", "confidence": 0.0, "reason": f"AI analysis error: {str(e)}"}

    def analyze_email_interest(self, email, all_messages, conversations):
        """Analyze interest for a specific email address using AI classification"""
        try:
            if not self.llm:
                return {
                    "status": "unknown",
                    "confidence": 0.0,
                    "reason": "AI system not available for classification",
                    "last_analyzed": datetime.now().isoformat(),
                    "indicators": {"positive": 0, "negative": 0, "total": 0}
                }
            
            # Get the most recent messages for better context
            recent_messages = conversations[-5:] if len(conversations) >= 5 else conversations
            recent_text = " ".join([conv.get("message", "") for conv in recent_messages])
            
            # Create a comprehensive prompt for AI analysis
            prompt = f"""Analyze this email conversation to determine if the client is interested in collaboration.

Email Address: {email}

Recent Messages:
{recent_text}

Full Conversation Context:
{all_messages}

Based on the conversation content, classify the client's interest level:

1. "interested" - Client shows clear interest in collaboration, asks about services, pricing, timeline, or expresses positive intent
2. "not_interested" - Client declines, says no, expresses disinterest, shows negative intent, or explicitly states they don't want to collaborate
3. "unknown" - Unclear or neutral response

Pay special attention to:
- Explicit statements like "I don't want to collaborate" or "I am interested"
- Questions about services, pricing, or process
- Positive or negative sentiment
- Recent messages (they carry more weight)

Respond with JSON format only:
{{
    "status": "interested|not_interested|unknown",
    "confidence": 0.0-1.0,
    "reason": "Brief explanation of the classification"
}}"""

            # Get AI analysis
            response = self.llm.invoke([HumanMessage(content=prompt)])
            
            try:
                # Parse JSON response
                import json
                result = json.loads(response.content)
                
                # Extract results
                status = result.get("status", "unknown")
                confidence = float(result.get("confidence", 0.0))
                reason = result.get("reason", "AI analysis completed")
                
                # Calculate indicators for compatibility (simplified)
                interest_count = 1 if status == "interested" else 0
                disinterest_count = 1 if status == "not_interested" else 0
                total_indicators = interest_count + disinterest_count
                
                return {
                    "status": status,
                    "confidence": round(confidence, 2),
                    "reason": f"AI Analysis: {reason}",
                    "last_analyzed": datetime.now().isoformat(),
                    "indicators": {
                        "positive": interest_count,
                        "negative": disinterest_count,
                        "total": total_indicators
                    }
                }
                
            except json.JSONDecodeError:
                # Fallback: parse text response
                content = response.content.lower()
                if "interested" in content and "not_interested" not in content:
                    return {
                        "status": "interested",
                        "confidence": 0.8,
                        "reason": "AI detected interest in collaboration",
                        "last_analyzed": datetime.now().isoformat(),
                        "indicators": {"positive": 1, "negative": 0, "total": 1}
                    }
                elif "not_interested" in content:
                    return {
                        "status": "not_interested",
                        "confidence": 0.8,
                        "reason": "AI detected disinterest in collaboration",
                        "last_analyzed": datetime.now().isoformat(),
                        "indicators": {"positive": 0, "negative": 1, "total": 1}
                    }
                else:
                    return {
                        "status": "unknown",
                        "confidence": 0.5,
                        "reason": "AI analysis inconclusive",
                        "last_analyzed": datetime.now().isoformat(),
                        "indicators": {"positive": 0, "negative": 0, "total": 0}
                    }
                    
        except Exception as e:
            print(f"Error in AI interest analysis for email {email}: {e}")
            return {
                "status": "error",
                "confidence": 0.0,
                "reason": f"AI analysis error for {email}: {str(e)}",
                "last_analyzed": datetime.now().isoformat(),
                "indicators": {"positive": 0, "negative": 0, "total": 0}
            }

    def get_user_conversation_history(self, user_id):
        """Get conversation history for a specific user"""
        if user_id not in self.user_conversations:
            self.load_user_conversation_history(user_id)
        return self.user_conversations.get(user_id, [])

    def load_user_conversation_history(self, user_id):
        """Load conversation history for a specific user"""
        history_file = f"conversation_histories/user_{user_id}_history.json"
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r') as f:
                    loaded_history = json.load(f)
                
                # Check if migration is needed
                if isinstance(loaded_history, list) and len(loaded_history) > 0:
                    if isinstance(loaded_history[0], dict) and "email_address" in loaded_history[0] and "conversation" in loaded_history[0]:
                        # Already in new format
                        self.user_conversations[user_id] = loaded_history
                        print(f"✅ Loaded conversation history for user {user_id} (new format)")
                    else:
                        # Need to migrate to new format
                        print(f"🔄 Migrating conversation history for user {user_id} to new format...")
                        self.migrate_to_email_based_structure(user_id)
                else:
                    self.user_conversations[user_id] = []
                    print(f"📄 Empty conversation history for user {user_id}")
                    
            except Exception as e:
                print(f"❌ Error loading conversation history for user {user_id}: {e}")
                self.user_conversations[user_id] = []
        else:
            self.user_conversations[user_id] = []
            print(f"📄 No existing conversation history for user {user_id}. Starting fresh.")

    def save_user_conversation_history(self, user_id):
        """Save conversation history for a specific user"""
        history_file = f"conversation_histories/user_{user_id}_history.json"
        try:
            with open(history_file, 'w') as f:
                json.dump(self.user_conversations.get(user_id, []), f, indent=4)
            print(f"✅ Saved conversation history for user {user_id}")
        except Exception as e:
            print(f"❌ Error saving conversation history for user {user_id}: {e}")

    def add_to_user_conversation(self, user_id, role, message, email_subject=None, email_address=None):
        """Add message to user's conversation history organized by email address"""
        if user_id not in self.user_conversations:
            self.load_user_conversation_history(user_id)
        
        # If no email address provided, try to extract from message
        if not email_address:
            email_address = self.extract_email_from_message(message, email_subject)
        
        # Only proceed if we have a valid email address
        if not email_address or email_address in ["unknown@email.com", "client@example.com"]:
            print(f"⚠️ No valid email address found, skipping conversation storage")
            return
        
        conversation_entry = {
            "role": role,
            "message": message,
            "timestamp": datetime.now().isoformat(),
            "email_subject": email_subject
        }
        
        # Find or create email-based conversation group
        email_found = False
        for email_group in self.user_conversations[user_id]:
            if email_group.get("email_address") == email_address:
                email_group["conversation"].append(conversation_entry)
                email_found = True
                break
        
        # If email group doesn't exist, create new one
        if not email_found:
            new_email_group = {
                "email_address": email_address,
                "conversation": [conversation_entry]
            }
            self.user_conversations[user_id].append(new_email_group)
        
        # Keep only last 20 email groups to prevent memory bloat
        if len(self.user_conversations[user_id]) > 20:
            self.user_conversations[user_id] = self.user_conversations[user_id][-20:]
        
        self.save_user_conversation_history(user_id)

    def clear_user_conversation_history(self, user_id):
        """Clear conversation history for a specific user"""
        try:
            # Clear in-memory data
            self.user_conversations[user_id] = []
            
            # Delete the history file
            history_file = f"conversation_histories/user_{user_id}_history.json"
            if os.path.exists(history_file):
                os.remove(history_file)
                print(f"🗑️ Deleted conversation history file for user {user_id}")
            
            # Also delete any email-specific history files
            import glob
            email_files = glob.glob(f"conversation_histories/user_{user_id}_email_*_history.json")
            for email_file in email_files:
                try:
                    os.remove(email_file)
                    print(f"🗑️ Deleted email-specific history file: {email_file}")
                except Exception as e:
                    print(f"⚠️ Could not delete {email_file}: {e}")
            
            print(f"✅ Successfully cleared all conversation history for user {user_id}")
            return True
            
        except Exception as e:
            print(f"❌ Error clearing conversation history for user {user_id}: {e}")
            return False

    def migrate_to_email_based_structure(self, user_id):
        """Migrate existing conversation history to email-based structure"""
        try:
            history_file = f"conversation_histories/user_{user_id}_history.json"
            if not os.path.exists(history_file):
                print(f"📄 No existing conversation history to migrate for user {user_id}")
                return True
            
            # Load existing history
            with open(history_file, 'r') as f:
                old_history = json.load(f)
            
            if not old_history:
                print(f"📄 Empty conversation history for user {user_id}")
                return True
            
            # Check if already in new format
            if isinstance(old_history, list) and len(old_history) > 0:
                if isinstance(old_history[0], dict) and "email_address" in old_history[0] and "conversation" in old_history[0]:
                    print(f"✅ Conversation history for user {user_id} already in new format")
                    return True
            
            print(f"🔄 Migrating conversation history for user {user_id}...")
            
            # Group conversations by email address
            email_groups = {}
            
            for conv in old_history:
                email_address = conv.get("email_address")
                
                # Skip conversations without valid email addresses
                if not email_address or email_address in ["unknown@email.com", "client@example.com"]:
                    print(f"⚠️ Skipping conversation with invalid email: {email_address}")
                    continue
                
                if email_address not in email_groups:
                    email_groups[email_address] = []
                
                # Create conversation entry without email_address (it's now in the group)
                conversation_entry = {
                    "role": conv.get("role"),
                    "message": conv.get("message"),
                    "timestamp": conv.get("timestamp"),
                    "email_subject": conv.get("email_subject")
                }
                email_groups[email_address].append(conversation_entry)
            
            # Create new structure
            new_history = []
            for email_address, conversations in email_groups.items():
                email_group = {
                    "email_address": email_address,
                    "conversation": conversations
                }
                new_history.append(email_group)
            
            # Save new structure
            with open(history_file, 'w') as f:
                json.dump(new_history, f, indent=4)
            
            # Update in-memory data
            self.user_conversations[user_id] = new_history
            
            print(f"✅ Successfully migrated {len(new_history)} email groups for user {user_id}")
            return True
            
        except Exception as e:
            print(f"❌ Error migrating conversation history for user {user_id}: {e}")
            return False

    def get_user_conversation_stats(self, user_id):
        """Get conversation statistics for a user"""
        history = self.get_user_conversation_history(user_id)
        if not history:
            return {"total_conversations": 0, "last_conversation": None, "unique_emails": 0}
        
        total_conversations = 0
        unique_emails = len(history)
        last_conversation = None
        
        for email_group in history:
            total_conversations += len(email_group.get("conversation", []))
            if email_group.get("conversation"):
                last_conv = email_group["conversation"][-1]
                if not last_conversation or last_conv["timestamp"] > last_conversation:
                    last_conversation = last_conv["timestamp"]
        
        return {
            "total_conversations": total_conversations,
            "last_conversation": last_conversation,
            "unique_emails": unique_emails
        }

    def generate_email_reply_with_pdf_context(self, subject: str, snippet: str, pdf_content: str = None, user_id: int = None, email_address: str = None) -> str:
        """Generate email reply with PDF context and conversation history for personalized responses"""
        if not self.llm:
            return "AI system not available."
        
        # Get user's conversation history
        conversation_context = ""
        if user_id:
            user_history = self.get_user_conversation_history(user_id)
            if user_history:
                # Get recent conversations for context
                conversation_context = "\n\nRECENT CONVERSATION CONTEXT:\n"
                for email_group in user_history:
                    email_addr = email_group.get("email_address", "")
                    conversations = email_group.get("conversation", [])
                    # Get last 5 conversations from each email for context
                    recent_conversations = conversations[-5:] if len(conversations) > 5 else conversations
                    for conv in recent_conversations:
                        if conv.get("email_subject") and conv.get("email_subject") != subject:
                            conversation_context += f"Previous email from {email_addr} ({conv['email_subject']}): {conv['message'][:200]}...\n"
        
        # Build the prompt with PDF context and conversation history
        base_prompt = f"""You are a professional brand collaboration manager. You received an email with:
Subject: {subject}
Message: {snippet}

Your role is to respond as a manager who will guide the potential client through the collaboration process. Be professional, informative, and helpful."""
        
        if pdf_content:
            # Add PDF context to the prompt
            pdf_context = f"""

IMPORTANT MANAGER CONTEXT FROM YOUR PDF/RATES/SERVICES:
{pdf_content[:2000]}...

Use this information to:
1. Reference your specific rates and services when relevant
2. Guide the client through your collaboration process
3. Provide clear next steps
4. Be professional but approachable
5. Answer their questions about pricing, services, or process

Write as a manager who is helping guide them through the collaboration process."""
            full_prompt = base_prompt + pdf_context
        else:
            full_prompt = base_prompt + "\n\nWrite a professional reply as a brand collaboration manager, offering to help guide them through the process."
        
        # Add conversation context if available
        if conversation_context:
            full_prompt += conversation_context + "\n\nUse the conversation context to maintain continuity and avoid repeating information already discussed."
        
        try:
            # Generate response with the enhanced prompt
            response = self.llm.invoke([HumanMessage(content=full_prompt)])
            
            # Clean the response to remove problematic characters
            cleaned_response = response.content
            # Replace common problematic characters
            cleaned_response = cleaned_response.replace('–', '-')  # em dash to regular dash
            cleaned_response = cleaned_response.replace('—', '-')  # em dash to regular dash
            cleaned_response = cleaned_response.replace('"', '"')  # smart quotes to regular quotes
            cleaned_response = cleaned_response.replace('"', '"')  # smart quotes to regular quotes
            cleaned_response = cleaned_response.replace(''', "'")  # smart apostrophe to regular apostrophe
            cleaned_response = cleaned_response.replace(''', "'")  # smart apostrophe to regular apostrophe
            
            # Add to user's conversation history
            if user_id:
                self.add_to_user_conversation(user_id, "client", snippet, subject, email_address)
                self.add_to_user_conversation(user_id, "manager", cleaned_response, subject, email_address)
            
            return cleaned_response
        except Exception as e:
            print(f"Error generating email reply: {e}")
            return "Thank you for your email. I'll get back to you soon with a detailed response about our collaboration process."

    def load_contract_stats(self):
        """Load contract statistics"""
        if os.path.exists(self.stats_file):
            try:
                with open(self.stats_file, 'r') as f:
                    self.contract_stats = json.load(f)
                print(f"✅ Loaded contract stats from {self.stats_file}")
            except Exception as e:
                print(f"❌ Error loading contract stats: {e}")
                self.contract_stats = {
                    "total_contracts": 0,
                    "contracts_done": 0,
                    "missed_contracts": 0,
                    "pending_contracts": 0,
                    "total_value": 0,
                    "average_value": 0
                }
        else:
            self.contract_stats = {
                "total_contracts": 0,
                "contracts_done": 0,
                "missed_contracts": 0,
                "pending_contracts": 0,
                "total_value": 0,
                "average_value": 0
            }
            print(f"📄 No existing contract stats file found. Starting fresh.")

    def save_contract_stats(self):
        """Save contract statistics"""
        try:
            with open(self.stats_file, 'w') as f:
                json.dump(self.contract_stats, f, indent=4)
            print(f"✅ Saved contract stats to {self.stats_file}")
        except Exception as e:
            print(f"❌ Error saving contract stats: {e}")

    def increment_contracts_done(self):
        """Increment successful contracts"""
        self.contract_stats["contracts_done"] += 1
        self.contract_stats["total_contracts"] += 1
        self.contract_stats["total_value"] += self.client_info.get('contract_value', 0)
        self.contract_stats["average_value"] = self.contract_stats["total_value"] / self.contract_stats["total_contracts"]
        print(f"✅ Incremented contracts_done. New count: {self.contract_stats['contracts_done']}")

    def increment_missed_contracts(self):
        """Increment missed contracts"""
        self.contract_stats["missed_contracts"] += 1
        self.contract_stats["total_contracts"] += 1
        self.contract_stats["total_value"] += self.client_info.get('contract_value', 0)
        self.contract_stats["average_value"] = self.contract_stats["total_value"] / self.contract_stats["total_contracts"]
        print(f"❌ Incremented missed_contracts. New count: {self.contract_stats['missed_contracts']}")

    def display_stats(self):
        """Display current statistics"""
        print("\n--- Current Statistics ---")
        print(f"Total Contracts: {self.contract_stats['total_contracts']}")
        print(f"Contracts Done: {self.contract_stats['contracts_done']}")
        print(f"Missed Contracts: {self.contract_stats['missed_contracts']}")
        print(f"Pending Contracts: {self.contract_stats['pending_contracts']}")
        print(f"Total Value: ${self.contract_stats['total_value']}")
        print(f"Average Contract Value: ${self.contract_stats['average_value']:.2f}")
        print("----------------------------\n")

    def load_conversation_history(self):
        """Load conversation history"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r') as f:
                    self.conversation_history = json.load(f)
                print(f"✅ Loaded conversation history from {self.history_file}")
            except Exception as e:
                print(f"❌ Error loading conversation history: {e}")
                self.conversation_history = []
        else:
            self.conversation_history = []
            print(f"📄 No existing conversation history file found. Starting fresh.")

    def save_conversation_history(self):
        """Save conversation history"""
        try:
            with open(self.history_file, 'w') as f:
                json.dump(self.conversation_history, f, indent=4)
            print(f"✅ Saved conversation history to {self.history_file}")
        except Exception as e:
            print(f"❌ Error saving conversation history: {e}")

    def append_to_history(self, role, message):
        """Add message to conversation history"""
        self.conversation_history.append({"role": role, "message": message})
        self.save_conversation_history()

    def show_services_menu(self):
        """Display available services"""
        print("\n--- Available Services ---")
        for key, service in self.services.items():
            print(f"{key.replace('_', ' ').title()}:")
            print(f"  Name: {service['name']}")
            print(f"  Price: ${service['price']}")
            print(f"  Description: {service['description']}")
            print(f"  Timeline: {service['timeline']}")
            print("-" * 20)
        print("Please select a service by typing its name (e.g., 'instagram_post', 'instagram_reel', etc.)")
        print("Or type 'back' to return to the main menu.")
        print("-----------------------------------\n")

    def get_contract_templates(self):
        """Return contract template options"""
        # This method is not fully implemented in the original file,
        # but it's included here as a placeholder.
        return ["Basic Contract", "Detailed Service Agreement", "NDA (Non-Disclosure Agreement)"]

    def interactive_mode(self):
        """Enhanced interactive mode"""
        print("Welcome to the Enhanced Brand Collaboration Bot!")
        print("I'm here to help you with your social media strategy.")
        print("Please type 'start' to begin the conversation.")
        print("-----------------------------------\n")

        while True:
            user_input = input("You: ").strip()
            if user_input.lower() == "start":
                self.conversation_stage = "greeting"
                print("Bot: Hello! I'm the Enhanced Brand Collaboration Bot. How can I assist you today?")
                self.append_to_history("user", "start")
                self.append_to_history("bot", "Hello! I'm the Enhanced Brand Collaboration Bot. How can I assist you today?")
            elif user_input.lower() == "back":
                self.conversation_stage = "greeting"
                print("Bot: Returning to main menu.")
                self.append_to_history("user", "back")
                self.append_to_history("bot", "Returning to main menu.")
            elif user_input.lower() == "stats":
                self.display_stats()
                self.append_to_history("user", "stats")
                self.append_to_history("bot", "Displaying current statistics.")
            elif user_input.lower() == "services":
                self.show_services_menu()
                self.append_to_history("user", "services")
                self.append_to_history("bot", "Displaying available services.")
            elif user_input.lower() == "templates":
                templates = self.get_contract_templates()
                print("Available contract templates:")
                for i, template in enumerate(templates, 1):
                    print(f"{i}. {template}")
                self.append_to_history("user", "templates")
                self.append_to_history("bot", "Displaying contract templates.")
            elif user_input.lower() == "exit":
                print("Bot: Goodbye!")
                self.append_to_history("user", "exit")
                self.append_to_history("bot", "Goodbye!")
                break
            else:
                ai_response = self.generate_ai_response(user_input)
                print(f"Bot: {ai_response}")
                self.append_to_history("user", user_input)
                self.append_to_history("bot", ai_response)

                # Attempt to detect agreement
                agreement_status = self.detect_agreement(user_input)
                if agreement_status is True:
                    self.process_agreement(self.client_info)
                elif agreement_status is False:
                    print("Bot: I'm sorry to hear that. Would you like to try again or discuss a different service?")
                    self.append_to_history("user", "disagree")
                    self.append_to_history("bot", "I'm sorry to hear that. Would you like to try again or discuss a different service?")
                else:
                    print("Bot: I'm not sure how to respond to that.")
                    self.append_to_history("user", "inconclusive")
                    self.append_to_history("bot", "I'm not sure how to respond to that.") 

    def remove_conversations_by_email(self, user_id, email):
        """Remove conversations from a specific email address from user's history"""
        try:
            history_file = f"conversation_histories/user_{user_id}_history.json"
            if os.path.exists(history_file):
                with open(history_file, 'r') as f:
                    conversations = json.load(f)
                
                # Remove conversations that contain this email address
                original_count = len(conversations)
                filtered_conversations = []
                
                for conv in conversations:
                    message = conv.get("message", "")
                    subject = conv.get("email_subject", "")
                    
                    # Check if this conversation contains the email address
                    if email not in message and email not in subject:
                        filtered_conversations.append(conv)
                
                removed_count = original_count - len(filtered_conversations)
                
                # Save updated conversations
                with open(history_file, 'w') as f:
                    json.dump(filtered_conversations, f, indent=4)
                
                # Update in-memory data
                if user_id in self.user_conversations:
                    self.user_conversations[user_id] = filtered_conversations
                
                print(f"✅ Removed {removed_count} conversations from email '{email}' for user {user_id}")
                return True
            else:
                print(f"❌ No conversation history file found for user {user_id}")
                return False
        except Exception as e:
            print(f"❌ Error removing conversations: {e}")
            return False 

    def add_conversation_by_email(self, user_id, email, role, message, email_subject=None):
        """Add conversation to a specific email address's history"""
        try:
            # Create email-specific history file
            email_history_file = f"conversation_histories/user_{user_id}_email_{email.replace('@', '_at_').replace('.', '_')}_history.json"
            
            # Load existing conversations for this email
            if os.path.exists(email_history_file):
                with open(email_history_file, 'r') as f:
                    email_conversations = json.load(f)
            else:
                email_conversations = []
            
            # Add new conversation
            conversation_entry = {
                "role": role,
                "message": message,
                "timestamp": datetime.now().isoformat(),
                "email_subject": email_subject,
                "email_address": email
            }
            
            email_conversations.append(conversation_entry)
            
            # Keep only last 50 conversations per email to prevent memory bloat
            if len(email_conversations) > 50:
                email_conversations = email_conversations[-50:]
            
            # Save email-specific conversation history
            with open(email_history_file, 'w') as f:
                json.dump(email_conversations, f, indent=4)
            
            print(f"✅ Added conversation for email {email} to user {user_id}")
            return True
            
        except Exception as e:
            print(f"❌ Error adding conversation for email {email}: {e}")
            return False

    def get_conversations_by_email(self, user_id, email):
        """Get conversation history for a specific email address"""
        try:
            history_file = f"conversation_histories/user_{user_id}_history.json"
            
            if os.path.exists(history_file):
                with open(history_file, 'r') as f:
                    history_data = json.load(f)
                
                # Find the email group for this specific email
                for email_group in history_data:
                    if isinstance(email_group, dict) and email_group.get("email_address") == email:
                        conversations = email_group.get("conversation", [])
                        print(f"✅ Loaded {len(conversations)} conversations for email {email}")
                        return conversations
                
                print(f"📄 No conversation history found for email {email}")
                return []
            else:
                print(f"📄 No conversation history file found for user {user_id}")
                return []
                
        except Exception as e:
            print(f"❌ Error loading conversations for email {email}: {e}")
            return []

    def get_all_email_addresses(self, user_id):
        """Get all email addresses that have conversation history"""
        try:
            history_file = f"conversation_histories/user_{user_id}_history.json"
            email_addresses = []
            
            if os.path.exists(history_file):
                with open(history_file, 'r') as f:
                    history_data = json.load(f)
                
                # Extract email addresses from the new structure
                for email_group in history_data:
                    if isinstance(email_group, dict) and "email_address" in email_group:
                        email_addresses.append(email_group["email_address"])
            
            print(f"✅ Found {len(email_addresses)} email addresses with conversation history")
            return email_addresses
            
        except Exception as e:
            print(f"❌ Error getting email addresses: {e}")
            return []

    def analyze_interest_by_email(self, user_id, email):
        """Analyze interest for a specific email address using AI classification"""
        try:
            conversations = self.get_conversations_by_email(user_id, email)
            
            if not conversations:
                return {
                    "status": "unknown",
                    "confidence": 0.0,
                    "reason": f"No conversation history found for {email}",
                    "last_analyzed": datetime.now().isoformat(),
                    "indicators": {"positive": 0, "negative": 0, "total": 0}
                }
            
            # Combine all messages from this email
            all_messages = " ".join([conv.get("message", "") for conv in conversations])
            
            # Use the AI-powered analysis method
            return self.analyze_email_interest(email, all_messages, conversations)
            
        except Exception as e:
            print(f"Error analyzing interest for email {email}: {e}")
            return {
                "status": "error",
                "confidence": 0.0,
                "reason": f"Error analyzing conversation for {email}: {str(e)}",
                "last_analyzed": datetime.now().isoformat(),
                "indicators": {"positive": 0, "negative": 0, "total": 0}
            }

    def delete_conversations_by_email(self, user_id, email):
        """Delete all conversations for a specific email address"""
        try:
            history_file = f"conversation_histories/user_{user_id}_history.json"
            
            if not os.path.exists(history_file):
                print(f"❌ No conversation history file found for user {user_id}")
                return False
            
            # Load current conversation history
            with open(history_file, 'r') as f:
                history_data = json.load(f)
            
            # Filter out the email group for this specific email
            original_count = len(history_data)
            filtered_history = []
            
            for email_group in history_data:
                if email_group.get("email_address") != email:
                    filtered_history.append(email_group)
                else:
                    print(f"🗑️ Removing email group for {email}")
            
            removed_count = original_count - len(filtered_history)
            
            if removed_count > 0:
                # Save updated history
                with open(history_file, 'w') as f:
                    json.dump(filtered_history, f, indent=4)
                
                # Update in-memory data
                if user_id in self.user_conversations:
                    self.user_conversations[user_id] = filtered_history
                
                print(f"✅ Successfully deleted {removed_count} email group(s) for {email}")
                return True
            else:
                print(f"❌ No conversation history found for email {email}")
                return False
                
        except Exception as e:
            print(f"❌ Error deleting conversations for email {email}: {e}")
            return False 

    def migrate_conversations_to_email_based(self, user_id):
        """Migrate existing conversation history to email-based storage"""
        try:
            # Get existing conversation history
            old_history = self.get_user_conversation_history(user_id)
            
            if not old_history:
                print(f"📄 No existing conversation history to migrate for user {user_id}")
                return True
            
            print(f"🔄 Starting migration for user {user_id}...")
            
            # Group conversations by email address
            email_conversations = {}
            
            for conv in old_history:
                if conv.get("role") == "client":  # Only process client messages
                    message = conv.get("message", "")
                    subject = conv.get("email_subject", "")
                    
                    # Extract email address from the message
                    email_address = self.extract_email_from_message(message, subject)
                    
                    if email_address:
                        if email_address not in email_conversations:
                            email_conversations[email_address] = []
                        
                        # Add this conversation
                        email_conversations[email_address].append(conv)
                        
                        # Find the corresponding manager response
                        for manager_conv in old_history:
                            if (manager_conv.get("role") == "manager" and 
                                manager_conv.get("email_subject") == conv.get("email_subject") and
                                manager_conv.get("timestamp") == conv.get("timestamp")):
                                email_conversations[email_address].append(manager_conv)
                                break
                    else:
                        # If no email found, create a generic email based on subject or timestamp
                        generic_email = f"unknown_{hash(subject) % 10000}@migrated.com"
                        if generic_email not in email_conversations:
                            email_conversations[generic_email] = []
                        email_conversations[generic_email].append(conv)
            
            # Save each email's conversations to separate files
            migrated_count = 0
            for email, conversations in email_conversations.items():
                # Clear any existing file for this email
                email_history_file = f"conversation_histories/user_{user_id}_email_{email.replace('@', '_at_').replace('.', '_')}_history.json"
                if os.path.exists(email_history_file):
                    os.remove(email_history_file)
                
                # Add all conversations for this email
                for conv in conversations:
                    success = self.add_conversation_by_email(
                        user_id, 
                        email, 
                        conv.get("role"), 
                        conv.get("message"), 
                        conv.get("email_subject")
                    )
                    if success:
                        migrated_count += 1
            
            print(f"✅ Migration completed for user {user_id}. Migrated {len(email_conversations)} email addresses with {migrated_count} conversations.")
            return True
            
        except Exception as e:
            print(f"❌ Error during migration: {e}")
            return False

    def extract_email_from_message(self, message, email_subject=None):
        """Extract email address from message or subject"""
        import re
        
        # Email pattern
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        
        # First try to extract from message
        emails = re.findall(email_pattern, message)
        if emails:
            return emails[0]  # Return first email found
        
        # If no email in message, try subject
        if email_subject:
            emails = re.findall(email_pattern, email_subject)
            if emails:
                return emails[0]
        
        # If still no email, try to extract from common patterns
        # Look for patterns like "from: email@domain.com" or "sent by: email@domain.com"
        from_pattern = r'(?:from|sent by|contact|email)[:\s]+([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,})'
        from_match = re.search(from_pattern, message, re.IGNORECASE)
        if from_match:
            return from_match.group(1)
        
        return None

    def add_conversation_with_email_extraction(self, user_id, role, message, email_subject=None):
        """Add conversation with automatic email extraction and storage"""
        try:
            # Extract email address from the message
            email_address = self.extract_email_from_message(message, email_subject)
            
            if email_address:
                # Store conversation by email address
                success = self.add_conversation_by_email(user_id, email_address, role, message, email_subject)
                if success:
                    print(f"✅ Stored conversation for email {email_address}")
                else:
                    print(f"❌ Failed to store conversation for email {email_address}")
            else:
                # If no email found, store in general history as fallback
                print(f"⚠️ No email address found in message, storing in general history")
                self.add_to_user_conversation(user_id, role, message, email_subject)
            
            return email_address
            
        except Exception as e:
            print(f"❌ Error in add_conversation_with_email_extraction: {e}")
            # Fallback to general storage
            self.add_to_user_conversation(user_id, role, message, email_subject)
            return None 