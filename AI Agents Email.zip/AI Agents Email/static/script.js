
// Enhanced Website Interactions and Animations

class RetrogradeSite {
    constructor() {
        this.isLoaded = false;
        this.init();
    }

    async init() {
        await this.waitForDOM();
        this.setupProgressBar();
        this.setupMobileMenu();
        this.setupSmoothScrolling();
        this.setupHeaderEffects();
        this.setupAnimationObserver();
        this.setupFAQAccordion();
        this.setupCounterAnimations();
        this.setupTypingEffect();
        this.setupRippleEffects();
        this.setupParallaxEffects();
        this.setupTiltEffects();
        this.setupLoadingAnimation();
        this.setupKeyboardNavigation();
        this.setupPerformanceMonitoring();
        this.isLoaded = true;
        console.log('🚀 Retrograde website loaded successfully!');
    }

    waitForDOM() {
        return new Promise(resolve => {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', resolve);
            } else {
                resolve();
            }
        });
    }

    // Enhanced Progress Bar
    setupProgressBar() {
        const progressBar = document.getElementById('progressBar');
        if (!progressBar) return;

        let ticking = false;

        const updateProgress = () => {
            const scrollPercent = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
            progressBar.style.width = `${Math.min(Math.max(scrollPercent, 0), 100)}%`;
            ticking = false;
        };

        window.addEventListener('scroll', () => {
            if (!ticking) {
                requestAnimationFrame(updateProgress);
                ticking = true;
            }
        });
    }

    // Enhanced Mobile Menu
    setupMobileMenu() {
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mobileNav = document.getElementById('mobileNav');
        const menuIcon = document.getElementById('menuIcon');

        if (!mobileMenuBtn || !mobileNav || !menuIcon) return;

        const toggleMenu = () => {
            const isActive = mobileNav.classList.contains('active');
            
            if (isActive) {
                mobileNav.classList.remove('active');
                menuIcon.className = 'fas fa-bars';
                mobileMenuBtn.style.transform = 'rotate(0deg)';
                document.body.style.overflow = 'auto';
            } else {
                mobileNav.classList.add('active');
                menuIcon.className = 'fas fa-times';
                mobileMenuBtn.style.transform = 'rotate(90deg)';
                document.body.style.overflow = 'hidden';
            }
        };

        mobileMenuBtn.addEventListener('click', toggleMenu);

        // Close menu when clicking on links
        const mobileNavLinks = mobileNav.querySelectorAll('a');
        mobileNavLinks.forEach(link => {
            link.addEventListener('click', () => {
                mobileNav.classList.remove('active');
                menuIcon.className = 'fas fa-bars';
                mobileMenuBtn.style.transform = 'rotate(0deg)';
                document.body.style.overflow = 'auto';
            });
        });

        // Close menu on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && mobileNav.classList.contains('active')) {
                toggleMenu();
            }
        });
    }

    // Enhanced Smooth Scrolling
    setupSmoothScrolling() {
        const navLinks = document.querySelectorAll('a[href^="#"]');

        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                
                const targetId = link.getAttribute('href');
                const targetSection = document.querySelector(targetId);
                
                if (targetSection) {
                    const header = document.querySelector('.header');
                    const headerHeight = header ? header.offsetHeight : 0;
                    const targetPosition = targetSection.offsetTop - headerHeight - 20;
                    
                    // Smooth scroll with easing
                    this.smoothScrollTo(targetPosition, 800);
                    
                    // Add ripple effect
                    this.createRipple(link, e, 'rgba(59, 130, 246, 0.3)');
                }
            });
        });
    }

    smoothScrollTo(target, duration) {
        const start = window.pageYOffset;
        const distance = target - start;
        let startTime = null;

        const easeInOutCubic = (t) => {
            return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
        };

        const animation = (currentTime) => {
            if (startTime === null) startTime = currentTime;
            const timeElapsed = currentTime - startTime;
            const progress = Math.min(timeElapsed / duration, 1);
            
            window.scrollTo(0, start + distance * easeInOutCubic(progress));
            
            if (progress < 1) {
                requestAnimationFrame(animation);
            }
        };

        requestAnimationFrame(animation);
    }

    // Enhanced Header Effects
    setupHeaderEffects() {
        const header = document.getElementById('header');
        if (!header) return;

        let lastScrollTop = 0;
        let ticking = false;

        const updateHeader = () => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            // Add scrolled class for styling
            if (scrollTop > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
            
            // Hide/show header based on scroll direction
            if (scrollTop > lastScrollTop && scrollTop > 100) {
                // Scrolling down
                header.style.transform = 'translateY(-100%)';
            } else {
                // Scrolling up
                header.style.transform = 'translateY(0)';
            }
            
            lastScrollTop = scrollTop;
            ticking = false;
        };

        window.addEventListener('scroll', () => {
            if (!ticking) {
                requestAnimationFrame(updateHeader);
                ticking = true;
            }
        });

        // Add transition to header
        header.style.transition = 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.3s ease, backdrop-filter 0.3s ease';
    }

    // Enhanced Animation Observer
    setupAnimationObserver() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const element = entry.target;
                    element.style.opacity = '1';
                    element.style.transform = 'translateY(0)';
                    
                    // Add staggered animations for grid items
                    if (element.parentNode.classList.contains('features-grid') ||
                        element.parentNode.classList.contains('problems-grid') ||
                        element.parentNode.classList.contains('solutions-grid')) {
                        
                        const delay = Array.from(element.parentNode.children).indexOf(element) * 100;
                        element.style.animationDelay = `${delay}ms`;
                        element.style.animation = 'slideInUp 0.6s cubic-bezier(0.4, 0, 0.2, 1) both';
                    }
                    
                    // Trigger counter animations
                    if (element.hasAttribute('data-counter') && !element.classList.contains('animated')) {
                        const target = parseInt(element.getAttribute('data-counter'));
                        this.animateCounter(element, target);
                        element.classList.add('animated');
                    }
                }
            });
        }, observerOptions);

        // Observe all animated elements
        const animatedElements = document.querySelectorAll(`
            .problem-card, .solution-card, .feature-card, .testimonial-card,
            .step, .hero-badge, .brands-grid .brand, .faq-item, .pricing-card,
            [data-counter], .stat-item
        `);

        animatedElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'opacity 0.6s cubic-bezier(0.4, 0, 0.2, 1), transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
            observer.observe(el);
        });
    }

    // Enhanced FAQ Accordion
    setupFAQAccordion() {
        const faqItems = document.querySelectorAll('.faq-item');

        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            
            if (question) {
                question.addEventListener('click', () => {
                    const isActive = item.classList.contains('active');
                    
                    // Close all other FAQ items
                    faqItems.forEach(otherItem => {
                        if (otherItem !== item) {
                            otherItem.classList.remove('active');
                            const otherAnswer = otherItem.querySelector('.faq-answer');
                            if (otherAnswer) otherAnswer.style.maxHeight = '0';
                        }
                    });
                    
                    // Toggle current item
                    const answer = item.querySelector('.faq-answer');
                    
                    if (isActive) {
                        item.classList.remove('active');
                        if (answer) answer.style.maxHeight = '0';
                    } else {
                        item.classList.add('active');
                        if (answer) {
                            answer.style.maxHeight = answer.scrollHeight + 'px';
                        }
                    }
                });
            }
        });
    }

    // Enhanced Counter Animation
    animateCounter(element, target, duration = 2000) {
        if (!element) return;
        
        let start = 0;
        const startTime = performance.now();
        
        const updateCounter = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function (ease-out cubic)
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const current = Math.floor(start + (target - start) * easeOut);
            
            if (target > 1000000) {
                element.textContent = `$${(current / 1000000).toFixed(1)}M`;
            } else if (target > 1000) {
                element.textContent = `${(current / 1000).toFixed(0)}K`;
            } else if (target < 100 && target > 10) {
                element.textContent = `${current}%`;
            } else {
                element.textContent = current.toLocaleString();
            }
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            } else {
                if (target > 1000000) {
                    element.textContent = `$${(target / 1000000).toFixed(1)}M`;
                } else if (target > 1000) {
                    element.textContent = `${(target / 1000).toFixed(0)}K`;
                } else if (target < 100 && target > 10) {
                    element.textContent = `${target}%`;
                } else {
                    element.textContent = target.toLocaleString();
                }
            }
        };
        
        requestAnimationFrame(updateCounter);
    }

    // Enhanced Typing Effect
    setupTypingEffect() {
        const heroText = document.getElementById('heroText');
        const cursor = document.getElementById('cursor');
        
        if (!heroText || !cursor) return;

        const texts = ['Creator Business', 'Revenue Stream', 'Brand Partnerships', 'Income Potential'];
        let textIndex = 0;
        let charIndex = 0;
        let isDeleting = false;
        let isPaused = false;

        const typeWriter = () => {
            const currentText = texts[textIndex];
            
            if (!isDeleting && !isPaused) {
                // Typing
                heroText.textContent = currentText.substring(0, charIndex + 1);
                charIndex++;
                
                if (charIndex === currentText.length) {
                    isPaused = true;
                    setTimeout(() => {
                        isPaused = false;
                        isDeleting = true;
                    }, 2000);
                }
            } else if (isDeleting && !isPaused) {
                // Deleting
                heroText.textContent = currentText.substring(0, charIndex - 1);
                charIndex--;
                
                if (charIndex === 0) {
                    isDeleting = false;
                    textIndex = (textIndex + 1) % texts.length;
                }
            }
            
            const typingSpeed = isDeleting ? 50 : 100;
            setTimeout(typeWriter, typingSpeed + Math.random() * 50);
        };

        // Start typing effect after initial delay
        setTimeout(typeWriter, 2000);
    }

    // Enhanced Ripple Effects
    setupRippleEffects() {
        const buttons = document.querySelectorAll('.btn-primary, .btn-primary-lg, .pricing-cta, .nav-link');

        buttons.forEach(button => {
            button.addEventListener('click', (e) => {
                this.createRipple(button, e);
            });
        });
    }

    createRipple(element, event, color = 'rgba(255, 255, 255, 0.6)') {
        const ripple = document.createElement('span');
        const rect = element.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;
        
        ripple.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            left: ${x}px;
            top: ${y}px;
            background: ${color};
            border-radius: 50%;
            pointer-events: none;
            z-index: 1000;
            animation: ripple 0.6s linear;
        `;
        
        element.style.position = 'relative';
        element.style.overflow = 'hidden';
        element.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    }

    // Enhanced Parallax Effects
    setupParallaxEffects() {
        let ticking = false;

        const updateParallax = () => {
            const scrolled = window.pageYOffset;
            
            // Floating shapes parallax
            const shapes = document.querySelectorAll('.shape');
            shapes.forEach((shape, index) => {
                const speed = (scrolled * (0.1 + index * 0.05));
                shape.style.transform = `translateY(${speed}px) rotate(${scrolled * 0.02}deg)`;
            });
            
            // Gradient orbs parallax
            const orbs = document.querySelectorAll('.gradient-orb');
            orbs.forEach((orb, index) => {
                const speed = (scrolled * (0.05 + index * 0.02));
                orb.style.transform = `translate${index % 2 === 0 ? 'Y' : 'X'}(${speed}px)`;
            });
            
            ticking = false;
        };

        window.addEventListener('scroll', () => {
            if (!ticking) {
                requestAnimationFrame(updateParallax);
                ticking = true;
            }
        });
    }

    // Enhanced 3D Tilt Effects
    setupTiltEffects() {
        const cards = document.querySelectorAll('.problem-card, .solution-card, .feature-card, .testimonial-card, .pricing-card');

        cards.forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                
                const rotateX = (y - centerY) / 10;
                const rotateY = (centerX - x) / 10;
                
                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`;
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateZ(0px)';
            });
        });
    }

    // Enhanced Loading Animation
    setupLoadingAnimation() {
        // Add loading complete animation
        document.body.style.opacity = '0';
        document.body.style.transition = 'opacity 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
        
        window.addEventListener('load', () => {
            setTimeout(() => {
                document.body.style.opacity = '1';
            }, 100);
        });

        // Create floating particles for hero section
        this.createFloatingParticles();
    }

    createFloatingParticles() {
        const hero = document.querySelector('.hero');
        if (!hero) return;
        
        for (let i = 0; i < 30; i++) {
            const particle = document.createElement('div');
            particle.style.cssText = `
                position: absolute;
                width: ${Math.random() * 4 + 2}px;
                height: ${Math.random() * 4 + 2}px;
                background: rgba(59, 130, 246, ${Math.random() * 0.3 + 0.1});
                border-radius: 50%;
                pointer-events: none;
                left: ${Math.random() * 100}%;
                top: ${Math.random() * 100}%;
                animation: float ${3 + Math.random() * 4}s ease-in-out infinite;
                animation-delay: ${Math.random() * 2}s;
            `;
            hero.appendChild(particle);
        }
    }

    // Enhanced Keyboard Navigation
    setupKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                // Close mobile menu
                const mobileNav = document.getElementById('mobileNav');
                const mobileMenuBtn = document.getElementById('mobileMenuBtn');
                const menuIcon = document.getElementById('menuIcon');
                
                if (mobileNav && mobileNav.classList.contains('active')) {
                    mobileNav.classList.remove('active');
                    if (menuIcon) menuIcon.className = 'fas fa-bars';
                    if (mobileMenuBtn) mobileMenuBtn.style.transform = 'rotate(0deg)';
                    document.body.style.overflow = 'auto';
                }
                
                // Close any active FAQ items
                const faqItems = document.querySelectorAll('.faq-item.active');
                faqItems.forEach(item => {
                    item.classList.remove('active');
                    const answer = item.querySelector('.faq-answer');
                    if (answer) answer.style.maxHeight = '0';
                });
            }
        });

        // Focus management for better accessibility
        const focusableElements = document.querySelectorAll(
            'a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])'
        );

        focusableElements.forEach(element => {
            element.addEventListener('focus', () => {
                element.style.outline = '2px solid #3b82f6';
                element.style.outlineOffset = '2px';
            });

            element.addEventListener('blur', () => {
                element.style.outline = '';
                element.style.outlineOffset = '';
            });
        });
    }

    // Performance Monitoring
    setupPerformanceMonitoring() {
        // Monitor Core Web Vitals
        if ('PerformanceObserver' in window) {
            try {
                const performanceObserver = new PerformanceObserver((list) => {
                    for (const entry of list.getEntries()) {
                        if (entry.entryType === 'largest-contentful-paint') {
                            console.log('LCP:', entry.startTime);
                        }
                        if (entry.entryType === 'first-input') {
                            console.log('FID:', entry.processingStart - entry.startTime);
                        }
                        if (entry.entryType === 'layout-shift') {
                            console.log('CLS:', entry.value);
                        }
                    }
                });

                performanceObserver.observe({ 
                    entryTypes: ['largest-contentful-paint', 'first-input', 'layout-shift'] 
                });
            } catch (e) {
                console.log('Performance observer not supported');
            }
        }

        // Log performance info
        console.log('🚀 Performance Info:', {
            'Interactive Elements': document.querySelectorAll('button, a, .card').length,
            'Animated Elements': document.querySelectorAll('[data-counter], .faq-item, .feature-card').length,
            'Total DOM Nodes': document.querySelectorAll('*').length
        });
    }
}

// Ripple effect for .auth-btn
function addRippleEffect(e) {
    const btn = e.currentTarget;
    const circle = document.createElement('span');
    circle.classList.add('ripple');
    const rect = btn.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    circle.style.width = circle.style.height = size + 'px';
    circle.style.left = (e.clientX - rect.left - size / 2) + 'px';
    circle.style.top = (e.clientY - rect.top - size / 2) + 'px';
    btn.appendChild(circle);
    circle.addEventListener('animationend', () => circle.remove());
}

document.querySelectorAll('.auth-btn').forEach(btn => {
    btn.addEventListener('click', addRippleEffect);
});

// === LOGIN FORM HANDLING ===
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        // Optionally, show a loading indicator here
        try {
            const res = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();
            if (res.ok) {
                // Redirect to admin dashboard if admin, else to user dashboard
                if (data.is_admin) {
                    window.location.href = 'admin-dashboard.html';
                } else {
                    window.location.href = 'dashboard.html';
                }
            } else {
                // Show error message
                showLoginError(data.error || 'Login failed.');
            }
        } catch (err) {
            showLoginError('Network error. Please try again.');
        }
    });

    function showLoginError(msg) {
        let errorDiv = document.getElementById('loginError');
        if (!errorDiv) {
            errorDiv = document.createElement('div');
            errorDiv.id = 'loginError';
            errorDiv.style.color = '#ef4444';
            errorDiv.style.marginTop = '10px';
            errorDiv.style.textAlign = 'center';
            loginForm.appendChild(errorDiv);
        }
        errorDiv.textContent = msg;
        errorDiv.style.display = 'block';
    }
}

// === SIGNUP FORM HANDLING ===
const signupForm = document.getElementById('signupForm');
if (signupForm) {
    signupForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        const instagram = document.getElementById('instagram').value.trim();
        const tiktok = document.getElementById('tiktok') ? document.getElementById('tiktok').value.trim() : '';
        const youtube = document.getElementById('youtube') ? document.getElementById('youtube').value.trim() : '';
        try {
            const res = await fetch('/api/signup', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password, instagram, tiktok, youtube })
            });
            const data = await res.json();
            if (res.ok) {
                showSignupMessage('Registration successful! You can now log in.', true);
                signupForm.reset();
            } else {
                showSignupMessage(data.error || 'Registration failed.', false);
            }
        } catch (err) {
            showSignupMessage('Network error. Please try again.', false);
        }
    });

    function showSignupMessage(msg, success) {
        let msgDiv = document.getElementById('signupMessage');
        if (!msgDiv) {
            msgDiv = document.createElement('div');
            msgDiv.id = 'signupMessage';
            msgDiv.style.marginTop = '10px';
            msgDiv.style.textAlign = 'center';
            signupForm.appendChild(msgDiv);
        }
        msgDiv.textContent = msg;
        msgDiv.style.display = 'block';
        msgDiv.style.color = success ? '#22c55e' : '#ef4444';
    }
}

// === PROFILE PAGE HANDLING ===
const profileForm = document.getElementById('profileForm');
if (profileForm) {
    // Fetch and display current profile data
    window.addEventListener('DOMContentLoaded', async () => {
        try {
            const res = await fetch('/api/profile');
            if (res.ok) {
                const data = await res.json();
                console.log('Profile API response:', data); // Debug log
                document.getElementById('username').value = data.username || '';
                document.getElementById('email').value = data.email || '';
                document.getElementById('name').value = data.name || '';
                document.getElementById('address').value = data.address || '';
                if (document.getElementById('gender')) document.getElementById('gender').value = data.gender || '';
                if (document.getElementById('dob')) document.getElementById('dob').value = data.dob || '';
                if (document.getElementById('phone')) document.getElementById('phone').value = data.phone || '';
                if (document.getElementById('bio')) document.getElementById('bio').value = data.bio || '';
                if (data.pfp) {
                    const pfpPreview = document.getElementById('pfpPreview');
                    pfpPreview.src = `/static${data.pfp}`;
                    pfpPreview.style.display = 'block';
                }
                // Show Admin Panel button if admin
                if (data.is_admin && document.getElementById('adminPanelBtn')) {
                    document.getElementById('adminPanelBtn').style.display = '';
                }
            } else {
                showProfileMessage('Failed to load profile.', false);
            }
        } catch (err) {
            showProfileMessage('Network error. Could not load profile.', false);
        }
    });

    // Handle profile form submission
    profileForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        try {
            const res = await fetch('/api/profile', {
                method: 'POST',
                body: formData
            });
            const data = await res.json();
            if (res.ok) {
                showProfileMessage('Profile saved successfully!', true);
            } else {
                showProfileMessage(data.error || 'Failed to save profile.', false);
            }
        } catch (err) {
            showProfileMessage('Network error. Could not save profile.', false);
        }
    });

    function showProfileMessage(msg, success) {
        const msgDiv = document.getElementById('profileMessage');
        msgDiv.textContent = msg;
        msgDiv.style.display = 'block';
        msgDiv.style.color = success ? '#22c55e' : '#ef4444';
    }
}

// === ADMIN PROFILE TAB HANDLING ===
function populateAdminProfileForm() {
    fetch('/api/profile').then(async res => {
        if (res.ok) {
            const data = await res.json();
            document.getElementById('adminUsername').value = data.username || '';
            document.getElementById('adminEmail').value = data.email || '';
            document.getElementById('adminName').value = data.name || '';
            document.getElementById('adminAddress').value = data.address || '';
            document.getElementById('adminGender').value = data.gender || '';
            document.getElementById('adminDob').value = data.dob || '';
            document.getElementById('adminPhone').value = data.phone || '';
            document.getElementById('adminBio').value = data.bio || '';
            if (data.pfp) {
                const pfpPreview = document.getElementById('adminPfpPreview');
                pfpPreview.src = `/static${data.pfp}`;
                pfpPreview.style.display = 'block';
            }
        }
    });
}
// Show admin profile form when tab is activated
const adminProfileTab = document.getElementById('tab-profile');
if (adminProfileTab) {
    const observer = new MutationObserver(() => {
        if (adminProfileTab.style.display !== 'none') {
            populateAdminProfileForm();
        }
    });
    observer.observe(adminProfileTab, { attributes: true, attributeFilter: ['style'] });
}

// === SETTINGS PAGE HANDLING ===
const gmailSettingsForm = document.getElementById('gmailSettingsForm');
if (gmailSettingsForm) {
    const connectedDiv = document.createElement('div');
    connectedDiv.id = 'gmailConnectedMessage';
    connectedDiv.style.display = 'none';
    connectedDiv.style.marginTop = '20px';
    connectedDiv.style.textAlign = 'center';
    connectedDiv.innerHTML = '<span style="color:#22c55e;font-weight:600;font-size:1.2em;">\u2714\ufe0f Gmail Connected!</span> <button id="disconnectGmailBtn" style="margin-left:16px;padding:6px 16px;border:none;background:#ef4444;color:white;border-radius:6px;cursor:pointer;">Disconnect</button>';
    gmailSettingsForm.parentNode.insertBefore(connectedDiv, gmailSettingsForm.nextSibling);

    // Prefill Gmail if available and show connected state
    window.addEventListener('DOMContentLoaded', async () => {
        try {
            const res = await fetch('/api/gmail-settings');
            if (res.ok) {
                const data = await res.json();
                if (data.gmail) {
                    // Hide form, show connected message
                    gmailSettingsForm.style.display = 'none';
                    connectedDiv.style.display = 'block';
                    // Disconnect button logic
                    document.getElementById('disconnectGmailBtn').onclick = async function() {
                        // Clear Gmail info by submitting empty values
                        const formData = new FormData();
                        formData.append('gmail', '');
                        formData.append('appPassword', '');
                        await fetch('/api/gmail-settings', { method: 'POST', body: formData });
                        // Show form again
                        gmailSettingsForm.style.display = 'block';
                        connectedDiv.style.display = 'none';
                        document.getElementById('gmail').value = '';
                        document.getElementById('appPassword').value = '';
                        document.getElementById('settingsMessage').style.display = 'none';
                    };
                } else {
                    gmailSettingsForm.style.display = 'block';
                    connectedDiv.style.display = 'none';
                }
                document.getElementById('gmail').value = data.gmail || '';
            }
        } catch (err) { /* ignore */ }
    });
    gmailSettingsForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        try {
            const res = await fetch('/api/gmail-settings', {
                method: 'POST',
                body: formData
            });
            const data = await res.json();
            const msgDiv = document.getElementById('settingsMessage');
            if (res.ok) {
                msgDiv.textContent = 'Gmail connected successfully!';
                msgDiv.style.color = '#22c55e';
                msgDiv.style.display = 'block';
                // Hide form, show connected message
                gmailSettingsForm.style.display = 'none';
                connectedDiv.style.display = 'block';
            } else {
                msgDiv.textContent = data.error || 'Failed to connect Gmail.';
                msgDiv.style.color = '#ef4444';
                msgDiv.style.display = 'block';
            }
        } catch (err) {
            const msgDiv = document.getElementById('settingsMessage');
            msgDiv.textContent = 'Network error. Please try again.';
            msgDiv.style.color = '#ef4444';
            msgDiv.style.display = 'block';
        }
    });
}

// === DASHBOARD EMAILS HANDLING ===
async function fetchAndDisplayEmails() {
    console.log('Fetching emails...');
    const emailsTableBody = document.getElementById('emailsTableBody');
    if (emailsTableBody) {
        console.log('Email table body found, loading emails...');
        try {
            const res = await fetch('/api/emails');
            console.log('Email response status:', res.status);
            if (res.ok) {
                const emails = await res.json();
                console.log('Emails loaded:', emails.length, 'emails');
                emailsTableBody.innerHTML = '';
                if (emails.length === 0) {
                    emailsTableBody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#888;">No emails found.</td></tr>';
                } else {
                    emails.forEach(email => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${email.sender || ''}</td>
                            <td>${email.subject || ''}</td>
                            <td>${email.date ? new Date(email.date).toLocaleString() : ''}</td>
                        `;
                        emailsTableBody.appendChild(row);
                    });
                }
            } else {
                console.log('Email API failed, showing error message');
                emailsTableBody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#ef4444;">Failed to load emails.</td></tr>';
            }
        } catch (err) {
            console.log('Email network error:', err);
            emailsTableBody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#ef4444;">Network error. Could not load emails.</td></tr>';
        }
    } else {
        console.log('Email table body not found');
    }
}



// Add CSS for ripple animation
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    @keyframes float {
        0%, 100% {
            transform: translateY(0px);
        }
        50% {
            transform: translateY(-20px);
        }
    }
    
    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .feature-card:hover .feature-icon {
        transform: scale(1.1) rotate(5deg);
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .testimonial-card:hover .quote-icon {
        transform: scale(1.2);
        color: #8b5cf6;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .brand:hover {
        transform: translateY(-4px) scale(1.05);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
`;
document.head.appendChild(style);

// Initialize the website
new RetrogradeSite();

// ===== USER DASHBOARD INTEREST CLASSIFICATION =====

let userInterestData = [];
let userAutoRefreshInterval = null;

// Load user's own interest analysis
async function loadMyInterestAnalysis() {
    console.log('Loading interest analysis...');
    try {
        const response = await fetch('/api/user/interest-analysis');
        console.log('Response status:', response.status);
        console.log('Response headers:', response.headers);
        
        if (response.ok) {
            const data = await response.json();
            console.log('Interest data loaded:', data);
            console.log('API response check - success:', data.success, 'contacts count:', data.contacts?.length, 'stats:', data.stats);
            
            if (data.success) {
                userInterestData = data.contacts;
                displayMyInterestClassification(data);
                updateMyInterestStats(data.stats);
            } else {
                console.error('API returned success: false');
                showMessage('Failed to load interest analysis', false);
            }
        } else {
            console.error('Failed to load interest analysis - HTTP error:', response.status);
            const errorText = await response.text();
            console.error('Error response:', errorText);
            showMessage('Failed to load interest analysis', false);
        }
    } catch (error) {
        console.error('Error loading interest analysis:', error);
        showMessage('Error loading interest analysis', false);
    }
}

// Display user's interest classification
function displayMyInterestClassification(data) {
    console.log('Displaying interest classification data:', data);
    console.log('Data structure check - has contacts:', !!data?.contacts, 'contacts length:', data?.contacts?.length);
    
    if (!data || !data.contacts || data.contacts.length === 0) {
        // Show message when no contacts exist
        const interestedGrid = document.getElementById('myInterestedContactsGrid');
        const notInterestedGrid = document.getElementById('myNotInterestedContactsGrid');
        const unknownGrid = document.getElementById('myUnknownContactsGrid');
        
        if (interestedGrid) interestedGrid.innerHTML = '<div class="no-contacts-message">No interested contacts found</div>';
        if (notInterestedGrid) notInterestedGrid.innerHTML = '<div class="no-contacts-message">No not interested contacts found</div>';
        if (unknownGrid) unknownGrid.innerHTML = '<div class="no-contacts-message">No contacts with unknown status found</div>';
        
        // Update counts to 0
        document.getElementById('myInterestedCount').textContent = '0';
        document.getElementById('myNotInterestedCount').textContent = '0';
        document.getElementById('myUnknownCount').textContent = '0';
        document.getElementById('myTotalContactsCount').textContent = '0';
        
        document.getElementById('myInterestedContactsCount').textContent = '0 contacts';
        document.getElementById('myNotInterestedContactsCount').textContent = '0 contacts';
        document.getElementById('myUnknownContactsCount').textContent = '0 contacts';
        
        return;
    }
    
    // Clear existing content
    const interestedGrid = document.getElementById('myInterestedContactsGrid');
    const notInterestedGrid = document.getElementById('myNotInterestedContactsGrid');
    const unknownGrid = document.getElementById('myUnknownContactsGrid');
    
    if (interestedGrid) interestedGrid.innerHTML = '';
    if (notInterestedGrid) notInterestedGrid.innerHTML = '';
    if (unknownGrid) unknownGrid.innerHTML = '';
    
    // Count contacts by status
    let interestedCount = 0;
    let notInterestedCount = 0;
    let unknownCount = 0;
    
    // Process each contact
    data.contacts.forEach(contact => {
        const contactCard = createMyContactCard(contact);
        
        switch (contact.interest_status) {
            case 'interested':
                if (interestedGrid) interestedGrid.appendChild(contactCard);
                interestedCount++;
                break;
            case 'not_interested':
                if (notInterestedGrid) notInterestedGrid.appendChild(contactCard);
                notInterestedCount++;
                break;
            case 'unknown':
            default:
                if (unknownGrid) unknownGrid.appendChild(contactCard);
                unknownCount++;
                break;
        }
    });
    
    // Update stats
    document.getElementById('myInterestedCount').textContent = interestedCount;
    document.getElementById('myNotInterestedCount').textContent = notInterestedCount;
    document.getElementById('myUnknownCount').textContent = unknownCount;
    document.getElementById('myTotalContactsCount').textContent = data.contacts.length;
    
    document.getElementById('myInterestedContactsCount').textContent = `${interestedCount} contact${interestedCount !== 1 ? 's' : ''}`;
    document.getElementById('myNotInterestedContactsCount').textContent = `${notInterestedCount} contact${notInterestedCount !== 1 ? 's' : ''}`;
    document.getElementById('myUnknownContactsCount').textContent = `${unknownCount} contact${unknownCount !== 1 ? 's' : ''}`;
    
    console.log(`Displayed ${interestedCount} interested, ${notInterestedCount} not interested, ${unknownCount} unknown contacts`);
}

// Create contact card for user dashboard
function createMyContactCard(contact, status) {
    const card = document.createElement('div');
    card.className = 'user-card';
    
    const confidenceColor = contact.confidence >= 0.8 ? '#10b981' : contact.confidence >= 0.6 ? '#f59e0b' : '#ef4444';
    const confidenceText = contact.confidence >= 0.8 ? 'High' : contact.confidence >= 0.6 ? 'Medium' : 'Low';
    
    card.innerHTML = `
        <div class="user-card-header">
            <div class="user-info">
                <img src="https://ui-avatars.com/api/?name=${contact.name}&background=8b5cf6&color=fff&size=40" 
                     alt="Contact Avatar" class="user-avatar">
                <div class="user-details">
                    <div class="user-name">${contact.name}</div>
                    <div class="user-email">${contact.email}</div>
                    <div class="user-id">Conversations: ${contact.conversation_count}</div>
                </div>
            </div>
            <div class="interest-status ${status}">
                ${status === 'interested' ? '✅' : status === 'not_interested' ? '❌' : '❓'}
            </div>
        </div>
        <div class="user-card-body">
            <div class="confidence-info">
                <span class="confidence-label">Confidence:</span>
                <span class="confidence-value" style="color: ${confidenceColor};">${confidenceText} (${Math.round(contact.confidence * 100)}%)</span>
            </div>
            <div class="reason-info">
                <span class="reason-label">Reason:</span>
                <span class="reason-text">${contact.reason}</span>
            </div>
            <div class="indicators-info">
                <span class="indicators-label">Indicators:</span>
                <span class="indicators-text">
                    <span style="color: #10b981;">+${contact.indicators.positive || 0}</span> / 
                    <span style="color: #ef4444;">-${contact.indicators.negative || 0}</span>
                </span>
            </div>
        </div>
        <div class="user-card-actions">
            <button class="btn-primary" onclick="viewMyInterestAnalysis('${contact.email}')" style="padding: 6px 12px; font-size: 0.9rem;">
                <i class="fas fa-search"></i> Analyze
            </button>
            <button class="btn-success" onclick="openMyContactForm('${contact.email}', '${contact.name}')" style="padding: 6px 12px; font-size: 0.9rem; margin-left: 4px;">
                <i class="fas fa-address-book"></i> Contact
            </button>
        </div>
    `;
    
    return card;
}

// Update user's interest statistics
function updateMyInterestStats(stats) {
    const interestedCountEl = document.getElementById('myInterestedCount');
    const notInterestedCountEl = document.getElementById('myNotInterestedCount');
    const unknownCountEl = document.getElementById('myUnknownCount');
    const totalCountEl = document.getElementById('myTotalContactsCount');
    
    if (interestedCountEl) interestedCountEl.textContent = stats.interested;
    if (notInterestedCountEl) notInterestedCountEl.textContent = stats.not_interested;
    if (unknownCountEl) unknownCountEl.textContent = stats.unknown;
    if (totalCountEl) totalCountEl.textContent = stats.total;
}

// Refresh user's interest analysis
async function refreshMyInterestAnalysis() {
    await loadMyInterestAnalysis();
    showMessage('Interest analysis refreshed successfully', true);
}

// Toggle user's auto-refresh
function toggleMyAutoRefresh() {
    const btn = document.getElementById('myAutoRefreshBtn');
    if (!btn) return;
    
    const isOn = btn.innerHTML.includes('ON');
    
    if (isOn) {
        // Turn off auto-refresh
        if (userAutoRefreshInterval) {
            clearInterval(userAutoRefreshInterval);
            userAutoRefreshInterval = null;
        }
        btn.innerHTML = '<i class="fas fa-clock"></i> Auto-Refresh: OFF';
        showMessage('Auto-refresh turned off', true);
    } else {
        // Turn on auto-refresh (every 3 minutes)
        userAutoRefreshInterval = setInterval(refreshMyInterestAnalysis, 3 * 60 * 1000);
        btn.innerHTML = '<i class="fas fa-clock"></i> Auto-Refresh: ON';
        showMessage('Auto-refresh turned on (every 3 minutes)', true);
    }
}

// Migrate conversations to email-based system
async function migrateConversations() {
    const btn = document.getElementById('migrateBtn');
    if (!btn) return;
    
    // Disable button and show loading
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Migrating...';
    
    try {
        const response = await fetch('/api/user/migrate-conversations', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            showMessage('Conversation history migrated successfully!', true);
            
            // Refresh the interest analysis to show the migrated data
            setTimeout(() => {
                refreshMyInterestAnalysis();
            }, 1000);
        } else {
            showMessage(`Migration failed: ${result.message || 'Unknown error'}`, false);
        }
    } catch (error) {
        console.error('Error during migration:', error);
        showMessage('Error during migration. Please try again.', false);
    } finally {
        // Re-enable button
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-database"></i> Migrate Data';
    }
}

// View interest analysis for specific contact
async function viewMyInterestAnalysis(contactEmail) {
    const contact = userInterestData.find(c => c.email === contactEmail);
    if (!contact) return;
    
    // Populate analysis modal
    document.getElementById('myAnalysisContactName').textContent = contact.name;
    document.getElementById('myAnalysisContactName').setAttribute('data-email', contact.email); // Add data-email attribute
    document.getElementById('myAnalysisCurrentStatus').textContent = contact.interest_status;
    document.getElementById('myAnalysisConfidence').textContent = `${Math.round(contact.confidence * 100)}%`;
    document.getElementById('myAnalysisLastAnalyzed').textContent = new Date(contact.last_analyzed).toLocaleString();
    document.getElementById('myAnalysisReason').textContent = contact.reason;
    document.getElementById('myPositiveIndicators').textContent = contact.indicators?.positive || 0;
    document.getElementById('myNegativeIndicators').textContent = contact.indicators?.negative || 0;
    
    // Show modal with proper positioning
    const modal = document.getElementById('myInterestAnalysisModal');
    modal.style.display = 'block';
    modal.style.position = 'fixed';
    modal.style.zIndex = '99999';
    modal.style.left = '0';
    modal.style.top = '0';
    modal.style.width = '100vw';
    modal.style.height = '100vh';
    
    // Prevent body scroll
    document.body.style.overflow = 'hidden';
}

// Open contact form for user
function openMyContactForm(contactEmail, contactName) {
    document.getElementById('myContactFormContactId').value = contactEmail;
    document.getElementById('myContactFormContactName').textContent = contactName;
    document.getElementById('myContactFormContactNameInput').value = contactName;
    document.getElementById('myContactFormEmail').value = contactEmail;
    
    // Show modal with proper positioning
    const modal = document.getElementById('myContactFormModal');
    modal.style.display = 'block';
    modal.style.position = 'fixed';
    modal.style.zIndex = '99999';
    modal.style.left = '0';
    modal.style.top = '0';
    modal.style.width = '100vw';
    modal.style.height = '100vh';
    
    // Prevent body scroll
    document.body.style.overflow = 'hidden';
}

// Save user's contact form
async function saveMyContactForm() {
    const contactName = document.getElementById('myContactFormContactNameInput').value;
    const email = document.getElementById('myContactFormEmail').value;
    const proposedPrice = document.getElementById('myContactFormPrice').value;
    const notes = document.getElementById('myContactFormNotes').value;
    
    if (!contactName || !email) {
        showMessage('Please fill in all required fields', false);
        return;
    }
    
    try {
        const response = await fetch('/api/user/contacts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contact_name: contactName,
                email: email,
                proposed_price: proposedPrice,
                notes: notes
            })
        });
        
        if (response.ok) {
            showMessage('Contact saved successfully', true);
            closeMyContactFormModal();
        } else {
            console.error('Failed to save contact');
            showMessage('Failed to save contact', false);
        }
    } catch (error) {
        console.error('Error saving contact:', error);
        showMessage('Error saving contact', false);
    }
}

// Close user's contact form modal
function closeMyContactFormModal() {
    document.getElementById('myContactFormModal').style.display = 'none';
    document.getElementById('myContactForm').reset();
    // Restore body scroll
    document.body.style.overflow = 'auto';
}

// Close user's interest analysis modal
function closeMyInterestAnalysisModal() {
    document.getElementById('myInterestAnalysisModal').style.display = 'none';
    // Restore body scroll
    document.body.style.overflow = 'auto';
}

// Delete contact from analysis modal
async function deleteMyContact() {
    const contactEmail = document.getElementById('myAnalysisContactName').getAttribute('data-email');
    const contactName = document.getElementById('myAnalysisContactName').textContent;
    
    if (!contactEmail) {
        showMessage('Contact email not found', false);
        return;
    }
    
    // Confirm deletion
    if (!confirm(`Are you sure you want to delete "${contactName}" from your contacts? This action cannot be undone.`)) {
        return;
    }
    
    try {
        // Call server API for permanent deletion
        const response = await fetch(`/api/user/contacts/${encodeURIComponent(contactEmail)}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            // Remove from local data only if server deletion succeeded
            userInterestData = userInterestData.filter(contact => contact.email !== contactEmail);
            
            // Update display with proper data structure
            const data = {
                contacts: userInterestData,
                stats: {
                    interested: userInterestData.filter(c => c.interest_status === 'interested').length,
                    not_interested: userInterestData.filter(c => c.interest_status === 'not_interested').length,
                    unknown: userInterestData.filter(c => c.interest_status === 'unknown').length,
                    total: userInterestData.length
                }
            };
            displayMyInterestClassification(data);
            updateMyInterestStats(data.stats);
            
            // Close modal
            closeMyInterestAnalysisModal();
            
            showMessage(`Contact "${contactName}" deleted successfully`, true);
        } else {
            // Server deletion failed
            showMessage(`Failed to delete contact: ${result.message || 'Unknown error'}`, false);
        }
        
    } catch (error) {
        console.error('Error deleting contact:', error);
        showMessage('Error deleting contact. Please try again.', false);
    }
}

// Show message function for notifications
function showMessage(message, isSuccess = true) {
    // Remove existing messages
    const existingMessages = document.querySelectorAll('.showMessage');
    existingMessages.forEach(msg => msg.remove());

    // Create new message
    const messageDiv = document.createElement('div');
    messageDiv.className = `showMessage ${isSuccess ? 'success' : 'error'}`;
    messageDiv.textContent = message;

    // Add to page
    document.body.appendChild(messageDiv);

    // Remove after 3 seconds
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 3000);
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing dashboard...');
    
    // Initialize interest analysis for user dashboard
    if (document.querySelector('.interest-classification-section')) {
        console.log('Interest section found, loading analysis...');
        loadMyInterestAnalysis();
        
        // Start auto-refresh
        userAutoRefreshInterval = setInterval(refreshMyInterestAnalysis, 3 * 60 * 1000);
    }
    
    // Initialize email fetching
    if (document.querySelector('.dashboard-emails')) {
        console.log('Email section found, loading emails...');
        fetchAndDisplayEmails();
        
        // Start email auto-refresh
        setInterval(fetchAndDisplayEmails, 5000);
    }
});