# Retrograde AI Email Agent

## Project Overview
A Flask-based web application for managing creator business tasks with AI-powered automation, including user authentication, dashboards, and admin features.

## Project Structure
- `app.py` — Main Flask backend
- `templates/` — All HTML files (move from root)
- `static/` — All static files (CSS, JS)
- `instance/users.db` — SQLite database
- `conversation_histories/` — User-specific AI conversation memory
- `pdfs/` — User-specific PDF documents for context
- `.env` — Environment variables (secret keys, mail config)

## Setup Instructions
1. **Clone the repository**
2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```
3. **Create a `.env` file** in the project root with the following:
   ```env
   SECRET_KEY=your-secret-key
   MAIL_SERVER=smtp.example.com
   MAIL_PORT=587
   MAIL_USE_TLS=True
   MAIL_USERNAME=your@email.com
   MAIL_PASSWORD=yourpassword
   MAIL_DEFAULT_SENDER=noreply@retrograde.com
   SQLALCHEMY_DATABASE_URI=sqlite:///instance/users.db
   SQLALCHEMY_TRACK_MODIFICATIONS=False
   ```
4. **Run the app**
   ```bash
   python app.py
   ```

## Usage
- Access the app at `http://localhost:5000`
- Use the signup/login forms to create and access accounts
- Admin login requires an account with `is_admin=True`

## Features

### AI Email Memory
- **User-specific conversation history**: Each user has their own AI conversation memory
- **Context-aware replies**: AI remembers previous email conversations and maintains continuity
- **Admin-only management**: Admins can view, refresh, and clear conversation history for any user
- **Dedicated AI Memory tab**: Complete overview of all users' conversation memory in the admin panel
- **Memory persistence**: Conversations are stored in JSON files per user
- **Smart context**: AI uses last 20 conversations for context when generating replies
- **Memory analytics**: View total conversations, email threads, and last activity across all users

### Email Automation
- **Automatic email fetching**: Fetches emails from Gmail using IMAP
- **AI-powered replies**: Generates contextual responses using OpenAI
- **PDF context integration**: Uses uploaded PDFs for personalized responses
- **Background processing**: Runs email fetching in background threads

### Interest Classification
- **AI-powered analysis**: Analyzes conversation history to detect user interest in collaboration
- **Regex + AI detection**: Combines keyword matching with AI analysis for accurate classification
- **Three categories**: Interested, Not Interested, Unknown status
- **Confidence scoring**: Provides confidence levels for each classification
- **Auto-refresh**: Updates analysis every 3 minutes automatically
- **Contact management**: Save contact forms for interested users
- **Manual override**: Admins can manually adjust interest status
- **Real-time updates**: Live classification updates as conversations progress

## Security Notes
- Never commit `.env` or `instance/users.db` to public repositories
- Change all default credentials and secret keys before deploying

## Deployment
- Use a production WSGI server (e.g., Gunicorn)
- Serve static files via a web server (e.g., Nginx)
- Enforce HTTPS and secure cookies

## License
MIT 